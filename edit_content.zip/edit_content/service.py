"""Service helpers for the Edit Content workflow."""

from __future__ import annotations

from typing import Any, AsyncIterator, Dict, Iterable, List, Sequence

from .prompts import build_editor_system_prompt

PREVIEW_LIMIT = 500


def build_edit_content_messages(request: Any) -> List[Dict[str, str]]:
    """
    Construct the message payload for the LLM based on the request details.

    The request is expected to provide:
      - messages: iterable of objects with `role` and `content`
      - editor_types: optional iterable of editor identifiers
      - document_text: optional string used to build a preview
    """

    editor_types: Sequence[str] | None = getattr(request, "editor_types", None)
    normalized_editor_types = list(editor_types or [])
    system_prompt = build_editor_system_prompt(normalized_editor_types)

    llm_messages: List[Dict[str, str]] = [{"role": "system", "content": system_prompt}]

    request_messages: Iterable[Any] = getattr(request, "messages", []) or []
    llm_messages.extend(
        {"role": msg.role, "content": msg.content}  # type: ignore[attr-defined]
        for msg in request_messages
    )

    document_text: str | None = getattr(request, "document_text", None)
    if document_text:
        preview = document_text[:PREVIEW_LIMIT]
        if len(document_text) > PREVIEW_LIMIT:
            preview += "..."

        llm_messages.append(
            {"role": "user", "content": f"[Document to Edit - Preview]\n{preview}"}
        )

    if normalized_editor_types:
        editor_context = (
            f"\n\n[Selected Editors]: {', '.join(normalized_editor_types)}"
        )
        llm_messages.append({"role": "user", "content": editor_context})

    return llm_messages


async def stream_edit_content(
    request: Any, llm: Any, *, temperature: float = 0.7, max_tokens: int = 4096
) -> AsyncIterator[Dict[str, str]]:
    """
    Stream edit-content responses from the provided LLM instance.

    Yields dictionaries compatible with the SSE payload used by `main.py`.
    """

    try:
        llm_messages = build_edit_content_messages(request)

        async for chunk in llm.stream_completion(
            messages=llm_messages,
            temperature=temperature,
            max_tokens=max_tokens,
        ):
            yield {"type": "content", "content": chunk}

        yield {"type": "complete"}

    except Exception as exc:  # pragma: no cover - defensive
        yield {"type": "error", "message": str(exc)}

