"""Document generation helpers for the Edit Content workflow."""

from __future__ import annotations

import io
import logging
import os
import platform
import re
import tempfile
from typing import List, Optional

from fastapi import HTTPException
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

from core.llm import get_llm_service

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.shared import Inches as DocxInches
from docx.shared import Pt as DocxPt
from docx.shared import RGBColor as DocxRGBColor
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P

logger = logging.getLogger(__name__)


TOC_KEYWORDS = (
    "table of contents",
    "contents",
    "table of content",
    "toc",
    "content",
)

_BOLD_MARKUP = re.compile(r"(\*\*|__)(.+?)\1")
_ITALIC_MARKUP = re.compile(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)|(?<!_)_(?!_)(.+?)(?<!_)_(?!_)")


def _resolve_template_path(template_path: str) -> Optional[str]:
    """
    Resolve the template path to an absolute path if the template exists.

    Returns the first existing path from multiple candidate locations, or None.
    """
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    normalized_template = os.path.normpath(template_path)
    backend_parent = os.path.dirname(backend_dir)

    candidates = [
        os.path.join(backend_dir, normalized_template),
        os.path.join(backend_parent, normalized_template),
    ]

    if os.path.isabs(template_path):
        candidates.append(template_path)
    else:
        candidates.append(os.path.join(os.getcwd(), normalized_template))

    for candidate in candidates:
        if os.path.exists(candidate):
            return candidate
    return None


def _apply_basic_formatting(text: str) -> str:
    """
    Convert simple Markdown-style bold/italic markers to basic HTML tags understood by ReportLab.

    Handles **bold**, __bold__, *italic*, and _italic_ markers.
    """
    if not text:
        return ""

    def bold_replacer(match: re.Match[str]) -> str:
        return f"<b>{match.group(2).strip()}</b>"

    def italic_replacer(match: re.Match[str]) -> str:
        captured = match.group(1) or match.group(2) or ""
        return f"<i>{captured.strip()}</i>"

    formatted = _BOLD_MARKUP.sub(bold_replacer, text)
    formatted = _ITALIC_MARKUP.sub(italic_replacer, formatted)
    return formatted


def _clear_document_body(document: Document) -> None:
    """Remove all paragraphs and tables from the document body."""
    body = document.element.body
    for element in list(body):
        if isinstance(element, (CT_P, CT_Tbl)):
            body.remove(element)


def _get_llm():
    try:
        return get_llm_service()
    except Exception as exc:  # pragma: no cover - defensive
        raise HTTPException(
            status_code=500, detail=f"LLM service not available: {str(exc)}"
        ) from exc


def extract_toc_from_content(content: str) -> Optional[List[str]]:
    """Check if table of contents already exists in content and extract it."""
    lines = content.split("\n")
    toc_started = False
    toc_ended = False
    headings: List[str] = []

    for line in lines:
        line_lower = line.strip().lower()

        if any(keyword in line_lower for keyword in TOC_KEYWORDS):
            if (
                line_lower in TOC_KEYWORDS
                or line_lower == "content"
                or any(
                    keyword in line_lower
                    for keyword in ("table of contents", "table of content")
                )
                or (
                    line.strip().startswith("#")
                    and any(keyword in line_lower for keyword in TOC_KEYWORDS)
                )
            ):
                toc_started = True
                continue

        if toc_started and not toc_ended:
            line_stripped = line.strip()

            if not line_stripped:
                continue

            if line_stripped.startswith("# "):
                if len(headings) > 0:
                    toc_ended = True
                    break
                continue

            if re.match(r"^[\d\-•*]\s+", line_stripped) or "..." in line_stripped or re.match(
                r"^\d+[\.\)]", line_stripped
            ):
                heading = re.sub(r"^[\d\-•*]\s+", "", line_stripped)
                heading = re.sub(r"\.\.\..*$", "", heading)
                heading = re.sub(r"\s+\d+$", "", heading)
                heading = heading.strip()
                if heading and len(heading) > 2:
                    headings.append(heading)
            elif line_stripped and not line_stripped.startswith("#"):
                if len(headings) < 20:
                    headings.append(line_stripped)
                else:
                    toc_ended = True
                    break

    if toc_started and len(headings) >= 2:
        logger.info("Found existing TOC in content with %s entries", len(headings))
        return headings[:25]

    return None


def extract_headings_from_content(content: str) -> List[str]:
    """Extract important headings from content for table of contents (only # and ##)."""
    headings: List[str] = []
    lines = content.split("\n")

    for line in lines:
        stripped = line.strip()
        heading_match = re.match(r"^(#{1,6})\s*(.+)$", stripped)
        if heading_match:
            headings.append(heading_match.group(2).strip())
        elif (
            line.startswith("**")
            and line.endswith("**")
            and len(line) > 4
            and len(line) < 100
        ):
            headings.append(line[2:-2].strip())

    return headings[:25]


async def generate_title_with_llm(content: str) -> str:
    """Generate a title from content using LLM."""
    try:
        llm = _get_llm()
        system_prompt = (
            "You are a professional title-creation specialist. Review the revised article provided and craft a unique, energetic, and publication-ready headline that reflects its core message while maintaining professional tone and precision."
        )
        user_prompt = (
            "Using the revised article below, propose a single professional and energetic title. Keep it concise (maximum 15 words), avoid generic phrasing, and return ONLY the title—no quotes, numbering, or commentary.\n\n"
            f"{content[:2000]}"
        )

        response = await llm.chat_completion(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.7,
            max_tokens=100,
        )

        title = response.content.strip().strip('"').strip("'")
        title = title.split("\n")[0].strip()
        return title or "Document"
    except Exception as exc:  # pragma: no cover - defensive
        logger.error("Error generating title with LLM: %s", exc)
        lines = content.split("\n")
        for line in lines:
            line = line.strip()
            if line.startswith("# "):
                return line[2:].strip()
            if line and len(line) < 100:
                return line[:100]
        return "Document"


async def generate_table_of_contents_with_llm(content: str) -> List[str]:
    """Generate table of contents from content using LLM - only important headings."""
    try:
        llm = _get_llm()
        system_prompt = (
            "You are a professional document editor. Generate a table of contents based on the content structure. "
            "Include only important main headings and major sections, not detailed sub-sections."
        )
        user_prompt = (
            "Analyze the following content and generate a table of contents with only the most important headings "
            "(main sections and major topics only, skip detailed sub-sections). Return ONLY a list of headings, "
            "one per line, without numbers or formatting:\n\n"
            f"{content[:3000]}"
        )

        response = await llm.chat_completion(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.7,
            max_tokens=500,
        )

        toc_lines = response.content.strip().split("\n")
        headings = []
        for line in toc_lines:
            line = re.sub(r"^\d+[\.\)]\s*", "", line.strip())
            line = re.sub(r"^[-*]\s*", "", line)
            if line and len(line) > 2:
                headings.append(line)

        if not headings or len(headings) < 2:
            headings = extract_headings_from_content(content)

        return headings[:25]
    except Exception as exc:  # pragma: no cover - defensive
        logger.error("Error generating TOC with LLM: %s", exc)
        return extract_headings_from_content(content)


async def create_pdf(
    content: str, title: Optional[str] = None, template_path: str = "template/Template.docx"
) -> bytes:
    """Generate a PDF from content by converting Word document to PDF."""
    try:
        if not title:
            title = await generate_title_with_llm(content)

        docx_bytes = await create_word_doc(
            content,
            title=title,
            template_path=template_path,
            use_template=True,
        )

        if platform.system() == "Windows":
            try:
                return convert_word_to_pdf_com(docx_bytes)
            except Exception as exc:  # pragma: no cover - Windows only
                logger.warning(
                    "Word COM automation failed: %s, falling back to ReportLab",
                    exc,
                )

        return create_pdf_from_word_content(docx_bytes, title)

    except Exception as exc:  # pragma: no cover - defensive
        logger.error("Error creating PDF: %s", exc)
        return create_pdf_simple_fallback(content, title or "Document")


def convert_word_to_pdf_com(docx_bytes: bytes) -> bytes:
    """Convert Word document to PDF using Word COM automation (Windows only)."""
    try:
        import pythoncom
        import win32com.client

        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as docx_file:
            docx_file.write(docx_bytes)
            docx_path = docx_file.name

        pdf_path = docx_path.replace(".docx", ".pdf")

        try:
            pythoncom.CoInitialize()
            word = win32com.client.Dispatch("Word.Application")
            word.Visible = False

            try:
                doc = word.Documents.Open(docx_path)
                doc.ExportAsFixedFormat(
                    OutputFileName=pdf_path,
                    ExportFormat=17,
                    OpenAfterExport=False,
                    OptimizeFor=0,
                    BitmapMissingFonts=True,
                    DocStructureTags=True,
                    CreateBookmarks=0,
                    UseISO19005_1=False,
                )
                doc.Close(False)

                with open(pdf_path, "rb") as pdf_file:
                    return pdf_file.read()

            finally:
                word.Quit()
                pythoncom.CoUninitialize()

        finally:
            try:
                os.unlink(docx_path)
                if os.path.exists(pdf_path):
                    os.unlink(pdf_path)
            except Exception as exc:  # pragma: no cover - best effort cleanup
                logger.warning("Error cleaning up temporary files: %s", exc)

    except ImportError as exc:  # pragma: no cover - optional dependency
        raise Exception("pywin32 not installed. Install it with: pip install pywin32") from exc
    except Exception as exc:  # pragma: no cover - defensive
        raise Exception(f"Word COM automation failed: {str(exc)}") from exc


def create_pdf_from_word_content(docx_bytes: bytes, title: str) -> bytes:
    """Create PDF from Word document content using ReportLab (fallback method)."""
    doc = Document(io.BytesIO(docx_bytes))
    content_text = [para.text.strip() for para in doc.paragraphs if para.text.strip()]

    buffer = io.BytesIO()
    doc_pdf = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        topMargin=1 * inch,
        bottomMargin=1 * inch,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "CustomTitle",
        parent=styles["Heading1"],
        fontSize=32,
        textColor="#E87722",
        spaceAfter=30,
        alignment=TA_LEFT,
        fontName="Helvetica-Bold",
    )
    body_style = ParagraphStyle(
        "CustomBody",
        parent=styles["BodyText"],
        fontSize=12,
        alignment=TA_JUSTIFY,
        spaceAfter=10,
        leading=21.6,
    )
    heading1_style = ParagraphStyle(
        "CustomHeading1",
        parent=styles["Heading1"],
        fontSize=20,
        textColor="#E87722",
        spaceAfter=12,
        spaceBefore=18,
        fontName="Helvetica-Bold",
        leading=36,
    )
    heading2_style = ParagraphStyle(
        "CustomHeading2",
        parent=styles["Heading2"],
        fontSize=18,
        textColor="#E87722",
        spaceAfter=10,
        spaceBefore=14,
        fontName="Helvetica-Bold",
        leading=32.4,
    )
    heading3_style = ParagraphStyle(
        "CustomHeading3",
        parent=styles["Heading2"],
        fontSize=16,
        textColor="#333333",
        spaceAfter=8,
        spaceBefore=12,
        fontName="Helvetica-Bold",
        leading=28.8,
    )
    title_content_style = ParagraphStyle(
        "TitleContent",
        parent=styles["Heading1"],
        fontSize=20,
        textColor="#E87722",
        spaceAfter=12,
        spaceBefore=18,
        fontName="Helvetica-Bold",
        leading=36,
    )
    bullet_style = ParagraphStyle(
        "Bullet",
        parent=styles["BodyText"],
        fontSize=12,
        alignment=TA_LEFT,
        spaceAfter=8,
        leading=21.6,
        leftIndent=20,
    )
    citation_style = ParagraphStyle(
        "Citation",
        parent=styles["BodyText"],
        fontSize=9,
        textColor="#666666",
        leftIndent=20,
        spaceAfter=6,
    )

    story: List[Paragraph] = []
    story.append(Paragraph(title, title_style))
    story.append(Spacer(1, 0.2 * inch))
    story.append(PageBreak())
    story.append(Spacer(1, 0.2 * inch))

    for text in content_text:
        if text.startswith("# "):
            story.append(Paragraph(text[2:].strip(), heading1_style))
            story.append(Spacer(1, 0.1 * inch))
        elif text.startswith("## "):
            story.append(Paragraph(text[3:].strip(), heading2_style))
            story.append(Spacer(1, 0.08 * inch))
        elif text.startswith("### "):
            story.append(Paragraph(text[4:].strip(), heading3_style))
            story.append(Spacer(1, 0.06 * inch))
        elif text.lower().startswith("title:"):
            title_text = re.sub(r"^title:\s*", "", text, flags=re.IGNORECASE).strip()
            if title_text:
                story.append(Paragraph(title_text, title_content_style))
                story.append(Spacer(1, 0.1 * inch))
        elif text.startswith("[") and "]" in text:
            story.append(Paragraph(text, citation_style))
            story.append(Spacer(1, 0.04 * inch))
        elif text.startswith(("- ", "* ", "• ")):
            list_text = re.sub(r"^[-*•]\s+", "", text).strip()
            bullet_text = (
                f'<font color="#E87722">•</font> {_apply_basic_formatting(list_text)}'
            )
            story.append(Paragraph(bullet_text, bullet_style))
            story.append(Spacer(1, 0.05 * inch))
        elif re.match(r"^\d+[\.\)]\s+", text):
            num_match = re.match(r"^(\d+)([\.\)])\s+(.*)", text)
            if num_match:
                num, punct, list_text = num_match.groups()
                numbered_text = (
                    f'<font color="#E87722"><b>{num}{punct}</b></font> '
                    f"{_apply_basic_formatting(list_text)}"
                )
                story.append(Paragraph(numbered_text, bullet_style))
            else:
                story.append(
                    Paragraph(_apply_basic_formatting(text), bullet_style)
                )
            story.append(Spacer(1, 0.05 * inch))
        else:
            story.append(Paragraph(_apply_basic_formatting(text), body_style))
            story.append(Spacer(1, 0.06 * inch))

    doc_pdf.build(story)
    buffer.seek(0)
    return buffer.getvalue()


def create_pdf_simple_fallback(content: str, title: str) -> bytes:
    """Simple PDF fallback when template conversion fails."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        topMargin=1 * inch,
        bottomMargin=1 * inch,
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "CustomTitle",
        parent=styles["Heading1"],
        fontSize=30,
        textColor="#E87722",
        spaceAfter=30,
        alignment=TA_LEFT,
    )
    body_style = ParagraphStyle(
        "CustomBody",
        parent=styles["BodyText"],
        fontSize=11,
        alignment=TA_JUSTIFY,
        spaceAfter=12,
        leading=14,
    )
    citation_style = ParagraphStyle(
        "Citation",
        parent=styles["BodyText"],
        fontSize=9,
        textColor="#666666",
        leftIndent=20,
        spaceAfter=6,
    )

    story: List[Paragraph] = []
    story.append(Paragraph(title, title_style))
    story.append(Spacer(1, 0.2 * inch))

    for para in content.split("\n\n"):
        if not para.strip():
            continue
        if para.startswith("**") and para.endswith("**"):
            story.append(Paragraph(para.strip("*").strip(), styles["Heading2"]))
        elif para.startswith("[") and "]" in para:
            story.append(Paragraph(para, citation_style))
        else:
            story.append(Paragraph(_apply_basic_formatting(para), body_style))
        story.append(Spacer(1, 0.1 * inch))

    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()


async def create_word_doc(
    content: str,
    title: Optional[str] = None,
    template_path: str = "template/Template.docx",
    use_template: bool = True,
) -> bytes:
    """Generate a Word document from content using template formatting."""
    if not title:
        logger.info("Title not provided, generating with LLM...")
        title = await generate_title_with_llm(content)
        logger.info("Generated title: %s", title)

    doc: Document
    if use_template:
        resolved_template_path = _resolve_template_path(template_path)
        if resolved_template_path:
            try:
                logger.info("Loading template from: %s", resolved_template_path)
                doc = Document(resolved_template_path)
                _clear_document_body(doc)
                logger.info("Template loaded and cleared, styles preserved")
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "Error loading template: %s, using default formatting", exc
                )
                doc = Document()
        else:
            logger.warning(
                "Template not found at %s, using default formatting", template_path
            )
            doc = Document()
    else:
        doc = Document()

    theme_color_primary = DocxRGBColor(0xE8, 0x77, 0x22)
    theme_color_secondary = DocxRGBColor(0x33, 0x33, 0x33)
    theme_color_text = DocxRGBColor(0x00, 0x00, 0x00)
    theme_color_citation = DocxRGBColor(0x66, 0x66, 0x66)

    title_para = doc.add_paragraph()
    try:
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    except AttributeError:
        title_para.alignment = 1

    title_run = title_para.add_run(title)
    title_run.font.size = DocxPt(32)
    title_run.bold = True
    title_run.font.color.rgb = theme_color_primary

    for _ in range(10):
        spacing_para = doc.add_paragraph()
        spacing_para.paragraph_format.space_after = DocxPt(12)

    headings = extract_toc_from_content(content)
    toc_found_in_content = headings is not None

    if not headings:
        logger.info("No TOC found in content, generating with LLM...")
        headings = await generate_table_of_contents_with_llm(content)
        logger.info("Generated %s TOC entries with LLM", len(headings))
        if not headings or len(headings) < 2:
            logger.info("LLM generated insufficient headings, extracting from content...")
            extracted_headings = extract_headings_from_content(content)
            if extracted_headings:
                headings = extracted_headings
                logger.info("Using %s extracted headings", len(headings))
    else:
        logger.info("Using existing TOC from content with %s entries", len(headings))

    skip_toc_in_content = toc_found_in_content

    if headings:
        content_headings_order = extract_headings_from_content(content) or []
        if content_headings_order:
            ordered_headings: List[str] = []
            used_keys = set()
            heading_lookup = {h.lower(): h for h in headings}
            for original_heading in content_headings_order:
                key = original_heading.strip()
                if not key:
                    continue
                key_lower = key.lower()
                if key_lower in heading_lookup and key_lower not in used_keys:
                    ordered_headings.append(heading_lookup[key_lower])
                    used_keys.add(key_lower)
            for heading in headings:
                key_lower = heading.lower()
                if key_lower not in used_keys:
                    ordered_headings.append(heading)
                    used_keys.add(key_lower)
            headings = ordered_headings

        doc.add_page_break()
        toc_heading = doc.add_heading("Content", level=1)
        toc_heading.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in toc_heading.runs:
            run.font.size = DocxPt(18)
            run.font.color.rgb = theme_color_primary
            run.bold = True

        spacing_para = doc.add_paragraph()
        spacing_para.paragraph_format.space_after = DocxPt(14)

        heading_to_page = {}
        base_page = 3
        words_per_page = 450

        lines = content.split("\n")
        current_word_count = 0
        seen_headings = set()

        for line in lines:
            line_stripped = line.strip()
            if skip_toc_in_content:
                line_lower = line_stripped.lower()
                if any(keyword in line_lower for keyword in TOC_KEYWORDS):
                    continue
                if re.match(r"^[\d\-•*]\s+", line_stripped) and "..." in line_stripped:
                    continue

            heading_text = None
            heading_match = re.match(r"^(#{1,6})\s*(.+)$", line_stripped)
            if heading_match:
                heading_text = heading_match.group(2).strip()

            if heading_text and heading_text.lower() not in seen_headings:
                estimated_words_before = current_word_count
                current_page = base_page + max(
                    0, (estimated_words_before // words_per_page)
                )
                if current_page < base_page:
                    current_page = base_page
                heading_to_page[heading_text.lower()] = current_page
                seen_headings.add(heading_text.lower())

            if not heading_text:
                current_word_count += len(line.split())
            else:
                current_word_count += 10

        prev_page_num = base_page - 1
        for heading in headings:
            para = doc.add_paragraph()
            para.paragraph_format.left_indent = DocxInches(0.25)
            para.paragraph_format.line_spacing = 1.3
            para.paragraph_format.space_after = DocxPt(6)
            tab_stops = para.paragraph_format.tab_stops
            tab_stops.clear_all()
            tab_stops.add_tab_stop(
                DocxInches(6.5), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS
            )

            run = para.add_run(heading)
            run.font.size = DocxPt(12)
            run.font.color.rgb = theme_color_text
            heading_lookup_key = heading.strip().lower()
            page_num = heading_to_page.get(heading_lookup_key)
            if page_num is None:
                page_num = max(prev_page_num + 1, base_page)
            prev_page_num = max(prev_page_num, page_num)
            para.add_run("\t")
            page_run = para.add_run(str(page_num))
            page_run.bold = True
            page_run.font.color.rgb = theme_color_primary
            page_run.font.size = DocxPt(12)

    doc.add_page_break()

    lines = content.split("\n")
    for line in lines:
        line = line.rstrip()
        stripped_line = line.strip()
        if not stripped_line:
            continue

        heading_match = re.match(r"^(#{1,6})\s*(.+)$", stripped_line)
        if heading_match:
            heading_level = len(heading_match.group(1))
            heading_text = heading_match.group(2).strip()
            level = min(heading_level, 4)
            heading_para = doc.add_heading(heading_text, level=level)
            heading_para.alignment = WD_ALIGN_PARAGRAPH.LEFT
            for run in heading_para.runs:
                if level == 1:
                    run.font.size = DocxPt(18)
                    run.font.color.rgb = theme_color_primary
                elif level == 2:
                    run.font.size = DocxPt(16)
                    run.font.color.rgb = theme_color_primary
                elif level == 3:
                    run.font.size = DocxPt(14)
                    run.font.color.rgb = theme_color_secondary
                else:
                    run.font.size = DocxPt(12)
                    run.font.color.rgb = theme_color_secondary
                run.bold = True
            continue

        if re.match(r"^[-*•·▪]\s+", line):
            list_text = re.sub(r"^[-*•·▪]\s+", "", line).strip()
            para = doc.add_paragraph(style="List Bullet")
            run = para.add_run(list_text)
            run.font.color.rgb = theme_color_text
            run.font.size = DocxPt(12)
            continue
        elif re.match(r"^\d+[\.\)]\s+", line):
            list_text = re.sub(r"^\d+[\.\)]\s+", "", line).strip()
            para = doc.add_paragraph(style="List Number")
            run = para.add_run(list_text)
            run.font.color.rgb = theme_color_text
            run.font.size = DocxPt(12)
            continue
        elif re.match(r"^\s{2,}[-*•·▪]\s+", line):
            para = doc.add_paragraph()
            para.paragraph_format.left_indent = DocxInches(0.5)
            para.paragraph_format.space_after = DocxPt(6)
            para.paragraph_format.line_spacing = 1.8
            para.paragraph_format.first_line_indent = DocxInches(-0.25)

            sub_bullet_run = para.add_run("▪ ")
            sub_bullet_run.font.size = DocxPt(11)
            sub_bullet_run.font.color.rgb = theme_color_secondary
            sub_bullet_run.bold = False

            list_text = re.sub(r"^\s+", "", line)
            list_text = re.sub(r"^[-*•·▪]\s+", "", list_text)
            list_text = re.sub(r"^\d+[\.\)]\s+", "", list_text).strip()
            text_run = para.add_run(list_text)
            text_run.font.size = DocxPt(11)
            text_run.font.color.rgb = theme_color_text
            continue
        elif re.match(r"^\s{4,}[-*•·▪]\s+", line):
            para = doc.add_paragraph()
            para.paragraph_format.left_indent = DocxInches(0.7)
            para.paragraph_format.space_after = DocxPt(5)
            para.paragraph_format.line_spacing = 1.8
            para.paragraph_format.first_line_indent = DocxInches(-0.2)

            sub_bullet_run = para.add_run("○ ")
            sub_bullet_run.font.size = DocxPt(10)
            sub_bullet_run.font.color.rgb = theme_color_secondary
            sub_bullet_run.bold = False

            list_text = re.sub(r"^\s+", "", line)
            list_text = re.sub(r"^[-*•·▪]\s+", "", list_text).strip()
            text_run = para.add_run(list_text)
            text_run.font.size = DocxPt(10)
            text_run.font.color.rgb = theme_color_text
            continue

        if line.startswith("[") and "]" in line:
            citation = doc.add_paragraph(line)
            citation.paragraph_format.left_indent = DocxInches(0.5)
            citation.paragraph_format.space_after = DocxPt(6)
            citation.paragraph_format.line_spacing = 1.8
            for run in citation.runs:
                run.font.size = DocxPt(9)
                run.font.color.rgb = theme_color_citation
                run.italic = True
            continue

        line_lower = stripped_line.lower()
        if any(
            keyword in line_lower
            for keyword in ["table of contents", "contents", "table of content"]
        ):
            continue

        para = doc.add_paragraph(line)
        para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        para.paragraph_format.space_after = DocxPt(10)
        para.paragraph_format.line_spacing = 1.8
        para.paragraph_format.first_line_indent = DocxInches(0)
        for run in para.runs:
            run.font.size = DocxPt(12)
            run.font.color.rgb = theme_color_text
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


__all__ = [
    "create_pdf",
    "create_pdf_from_word_content",
    "create_pdf_simple_fallback",
    "create_word_doc",
    "extract_headings_from_content",
    "extract_toc_from_content",
    "generate_table_of_contents_with_llm",
    "generate_title_with_llm",
    "convert_word_to_pdf_com",
]

