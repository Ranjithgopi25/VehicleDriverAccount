(function(window) {
  window._env = window._env || {};
  window._env.apiUrl = 'http://localhost:8000';
}(this));

