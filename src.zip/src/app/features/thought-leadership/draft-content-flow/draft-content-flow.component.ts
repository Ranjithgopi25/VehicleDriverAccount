import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { CanvasStateService } from '../../../core/services/canvas-state.service';
import { TlChatBridgeService } from '../../../core/services/tl-chat-bridge.service';
import { GuidedDialogComponent } from '../../../shared/components/guided-dialog/guided-dialog.component';
import { ThoughtLeadershipMetadata } from '../../../core/models';
import { StartingMaterialComponent, StartingMaterial } from '../components/starting-material/starting-material.component';
import { ResearchSourcesComponent, ResearchSourceSelection } from '../components/research-sources/research-sources.component';

@Component({
  selector: 'app-draft-content-flow',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule,
    FormsModule,
    GuidedDialogComponent,
    StartingMaterialComponent,
    ResearchSourcesComponent
  ],
  templateUrl: './draft-content-flow.component.html',
  styleUrls: ['./draft-content-flow.component.scss']
})
export class DraftContentFlowComponent implements OnInit {
  @ViewChild(StartingMaterialComponent) startingMaterialComponent?: StartingMaterialComponent;

  // Single combined form
  page1Form!: FormGroup;
  page2Form!: FormGroup;

  // Generation state
  isGenerating: boolean = false;
  generatedContent: string = '';
  fileReadError: string = '';
  podcastAudioUrl: string = '';
  podcastFilename: string = '';
  isConvertingToPodcast: boolean = false;
  showResearchSection: boolean = false;

  // Starting material data
  startingMaterial: StartingMaterial = { type: null };

  // Research source selection
  researchSourceSelection: ResearchSourceSelection = {
    uploadedContent: false,
    pwcProprietary: false,
    pwcLicensed: false,
    externalResearch: false
  };

  // Additional research data
  additionalDocuments: File[] = [];
  researchAreas: string = '';
  researchLinks: string = '';
  supportingDocuments: File[] = [];
  additionalGuidelines: string = '';

  constructor(
    private fb: FormBuilder,
    public tlFlowService: TlFlowService,
    private chatService: ChatService,
    private canvasStateService: CanvasStateService,
    private tlChatBridge: TlChatBridgeService
  ) {}

  ngOnInit(): void {
    this.initializeForms();
  }

  private initializeForms(): void {
    // Page 1: Topic, Content Type, Length, Audience, Starting Material
    this.page1Form = this.fb.group({
      topic: ['', Validators.required],
      contentType: ['', Validators.required],
      lengthMin: [''],
      lengthMax: [''],
      audience: ['', Validators.required],
      // Starting material validated via component
    });

    // Page 2: Additional documents, Research areas, Research sources, Guidelines
    this.page2Form = this.fb.group({
      hasResearchAreas: [false],
      researchAreasText: [''],
      additionalGuidelines: ['']
    });
  }

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'draft-content';
  }

  onClose(): void {
    this.resetForm();
    this.tlFlowService.closeFlow();
  }

  resetForm(): void {
    this.isGenerating = false;
    this.generatedContent = '';
    this.fileReadError = '';
    this.podcastAudioUrl = '';
    this.podcastFilename = '';
    this.startingMaterial = { type: null };
    this.researchSourceSelection = {
      uploadedContent: false,
      pwcProprietary: false,
      pwcLicensed: false,
      externalResearch: false
    };
    this.additionalDocuments = [];
    this.researchAreas = '';
    this.researchLinks = '';
    this.supportingDocuments = [];
    this.additionalGuidelines = '';
    this.initializeForms();
  }

  canGenerate(): boolean {
    // Check Page 1 form validity
    if (!this.page1Form.valid) {
      return false;
    }

    // Check starting material (must have either file or text)
    if (!this.startingMaterial.type) {
      return false;
    }

    return true;
  }

  toggleResearchSection(): void {
    this.showResearchSection = !this.showResearchSection;
  }

  // Content type selection
  selectContentType(type: 'article' | 'blog' | 'white-paper' | 'executive-brief' | 'podcast'): void {
    this.page1Form.patchValue({ contentType: type });
  }

  getWordCountForContentType(): string {
    const contentType = this.page1Form.get('contentType')?.value;
    switch (contentType) {
      case 'article':
        return '2,000-3,000 words';
      case 'blog':
        return '800-1,500 words';
      case 'white-paper':
        return '5,000+ words';
      case 'executive-brief':
        return '500-1,000 words';
      default:
        return '';
    }
  }

  // Starting material handler
  onStartingMaterialChange(material: StartingMaterial): void {
    this.startingMaterial = material;
  }

  // Research sources handler
  onResearchSourcesChange(selection: ResearchSourceSelection): void {
    this.researchSourceSelection = selection;
  }

  // File handlers
  onAdditionalDocumentsSelect(event: any): void {
    const files = Array.from(event.target.files) as File[];
    this.additionalDocuments = files;
  }

  onSupportingDocumentsSelect(event: any): void {
    const files = Array.from(event.target.files) as File[];
    this.supportingDocuments = files;
  }

  // Research areas toggle
  onResearchAreasToggle(hasAreas: boolean): void {
    this.page2Form.patchValue({ hasResearchAreas: hasAreas });
    if (!hasAreas) {
      this.page2Form.patchValue({ researchAreasText: '' });
      this.researchAreas = '';
    }
  }

  async generateContent(): Promise<void> {
    if (!this.canGenerate()) {
      return;
    }

    this.isGenerating = true;
    this.fileReadError = '';
    this.podcastAudioUrl = '';
    this.podcastFilename = '';

    const formData = this.buildFormData();

    // Handle podcast generation separately
    if (formData.contentType === 'podcast') {
      await this.generatePodcast(formData);
      return;
    }

    try {
      // Build content message
      let contentMessage = this.buildContentMessage(formData);

      // Add reference documents if provided
      if (formData.startingMaterialFile) {
        const fileContent = await this.extractFileText(formData.startingMaterialFile);
        contentMessage += `\n\n--- Starting Material (${formData.startingMaterialFile.name}) ---\n${fileContent}`;
      } else if (formData.startingMaterialText) {
        contentMessage += `\n\n--- Starting Material (User Provided) ---\n${formData.startingMaterialText}`;
      }

      // Add additional documents
      if (this.additionalDocuments.length > 0) {
        for (const file of this.additionalDocuments) {
          const fileContent = await this.extractFileText(file);
          contentMessage += `\n\n--- Additional Document (${file.name}) ---\n${fileContent.substring(0, 5000)}`;
        }
      }

      // Add supporting documents for research
      if (this.supportingDocuments.length > 0) {
        for (const file of this.supportingDocuments) {
          const fileContent = await this.extractFileText(file);
          contentMessage += `\n\n--- Research Document (${file.name}) ---\n${fileContent.substring(0, 5000)}`;
        }
      }

      // Add research links
      if (this.researchLinks.trim()) {
        contentMessage += `\n\nResearch Links:\n${this.researchLinks}`;
      }

      // Add research areas
      if (formData.researchAreas) {
        contentMessage += `\n\nSpecific Research Areas to Explore:\n${formData.researchAreas}`;
      }

      // Add research source selection context
      if (formData.hasResearch) {
        const activeSources = [];
        if (this.researchSourceSelection.uploadedContent) activeSources.push('Uploaded Content');
        if (this.researchSourceSelection.externalResearch) activeSources.push('External Research');
        if (this.researchSourceSelection.pwcProprietary) activeSources.push('PwC Proprietary Research');
        if (this.researchSourceSelection.pwcLicensed) activeSources.push('PwC Licensed Third Party Tools');

        if (activeSources.length > 0) {
          contentMessage += `\n\nResearch Sources Requested: ${activeSources.join(', ')}`;
        }
      }

      // Add additional guidelines
      if (formData.additionalGuidelines) {
        contentMessage += `\n\nAdditional Guidelines:\n${formData.additionalGuidelines}`;
      }

      const messages = [{
        role: 'user' as const,
        content: contentMessage
      }];

      // Stream content generation
      this.chatService.streamDraftContent(messages).subscribe({
        next: (data: any) => {
          if (typeof data === 'string') {
            this.generatedContent += data;
          } else if (data.type === 'content' && data.content) {
            this.generatedContent += data.content;
          }
        },
        error: (error: any) => {
          console.error('Error generating content:', error);
          this.generatedContent = 'Sorry, there was an error generating your content. Please try again.';
          this.isGenerating = false;
        },
        complete: () => {
          this.isGenerating = false;

          // Send content to chat window
          if (this.generatedContent) {
            this.sendToChat();
          }
        }
      });
    } catch (error) {
      console.error('Error in content generation:', error);
      this.fileReadError = 'Error processing files. Please try again.';
      this.isGenerating = false;
    }
  }

  private buildFormData() {
    const page1 = this.page1Form.value;
    const page2 = this.page2Form.value;

    return {
      topic: page1.topic,
      contentType: page1.contentType,
      lengthMin: page1.lengthMin,
      lengthMax: page1.lengthMax,
      audience: page1.audience,
      startingMaterialFile: this.startingMaterial.file,
      startingMaterialText: this.startingMaterial.text,
      hasResearch: page2.hasResearchAreas,
      researchAreas: page2.researchAreasText,
      additionalGuidelines: page2.additionalGuidelines
    };
  }

  private buildContentMessage(formData: any): string {
    const wordCount = this.getWordCountForContentType();
    let message = `I want to draft a ${formData.contentType}${wordCount ? ` (${wordCount})` : ''}.\n\n`;
    message += `Topic: ${formData.topic}\n`;
    message += `Target Audience: ${formData.audience}\n`;

    if (formData.lengthMin && formData.lengthMax) {
      message += `Desired Length: ${formData.lengthMin} - ${formData.lengthMax} words\n`;
    }

    return message;
  }

  private async extractFileText(file: File): Promise<string> {
    const fileName = file.name.toLowerCase();

    // For PDF and DOCX files, use backend extraction
    if (fileName.endsWith('.pdf') || fileName.endsWith('.docx')) {
      const formData = new FormData();
      formData.append('file', file);

      try {
        const response = await fetch('/api/extract-text', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          throw new Error('Failed to extract text from file');
        }

        const data = await response.json();
        return data.text || '';
      } catch (error) {
        console.error('Error extracting text:', error);
        throw error;
      }
    }

    // For TXT and MD files, read directly
    if (fileName.endsWith('.txt') || fileName.endsWith('.md')) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          resolve(content || '');
        };
        reader.onerror = reject;
        reader.readAsText(file);
      });
    }

    throw new Error('Unsupported file type');
  }

  private sendToChat(): void {
    const contentType = this.page1Form.get('contentType')?.value;
    const topic = this.page1Form.get('topic')?.value;
    
    const contentTypeFormatted = contentType === 'white-paper' ? 'white_paper' as const : 
                                contentType === 'executive-brief' ? 'executive_brief' as const : 
                                contentType as 'article' | 'blog';

    const metadata: ThoughtLeadershipMetadata = {
      contentType: contentTypeFormatted,
      topic: topic || 'Generated Content',
      fullContent: this.generatedContent,
      showActions: true,
      podcastAudioUrl: this.podcastAudioUrl || undefined,
      podcastFilename: this.podcastFilename || undefined
    };

    // Send to chat
    this.tlChatBridge.sendToChat(this.generatedContent, metadata);

    // Close dialog after sending
    setTimeout(() => {
      this.onClose();
    }, 300);
  }

  downloadContent(format: 'txt' | 'docx' | 'pdf'): void {
    const blob = new Blob([this.generatedContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `draft-content.${format}`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  copyToClipboard(): void {
    navigator.clipboard.writeText(this.generatedContent);
  }

  openInCanvas(): void {
    if (!this.generatedContent) {
      return;
    }

    const title = this.page1Form.get('topic')?.value || 'Generated Content';
    const contentType = this.page1Form.get('contentType')?.value;
    const contentTypeFormatted = contentType === 'white-paper' ? 'white_paper' : 
                                contentType === 'executive-brief' ? 'executive_brief' : 
                                contentType as 'article' | 'blog';

    this.canvasStateService.loadFromContent(
      this.generatedContent,
      title,
      contentTypeFormatted
    );

    this.onClose();
  }

  private async generatePodcast(formData: any): Promise<void> {
    let contentText = `Topic: ${formData.topic}. Target Audience: ${formData.audience}.`;

    // Add starting material
    if (formData.startingMaterialText) {
      contentText += `\n\nStarting Material:\n${formData.startingMaterialText}`;
    }

    // Add research areas if specified
    if (formData.researchAreas) {
      contentText += `\n\nResearch Areas: ${formData.researchAreas}`;
    }

    // Collect all files for podcast generation
    const podcastFiles: File[] = [];
    if (formData.startingMaterialFile) {
      podcastFiles.push(formData.startingMaterialFile);
    }
    if (this.additionalDocuments.length > 0) {
      podcastFiles.push(...this.additionalDocuments);
    }
    if (this.supportingDocuments.length > 0) {
      podcastFiles.push(...this.supportingDocuments);
    }

    const customization = formData.additionalGuidelines || null;

    let scriptContent = '';
    let audioBase64 = '';

    this.chatService.generatePodcast(
      podcastFiles.length > 0 ? podcastFiles : null,
      contentText,
      customization,
      'dialogue'
    ).subscribe({
      next: (data) => {
        if (data.type === 'progress') {
          this.generatedContent = `Generating podcast...\n\n${data.message}`;
        } else if (data.type === 'script') {
          scriptContent = data.content;
          this.generatedContent = `📻 **Podcast Generated Successfully!**\n\n**Script:**\n\n${scriptContent}\n\n`;
        } else if (data.type === 'complete') {
          audioBase64 = data.audio;
          this.generatedContent += `\n🎧 **Audio Ready!** Listen to your podcast below or download it as an MP3 file.\n\n`;

          const audioBlob = this.base64ToBlob(audioBase64, 'audio/mpeg');
          const audioUrl = URL.createObjectURL(audioBlob);

          this.podcastAudioUrl = audioUrl;
          this.podcastFilename = 'podcast.mp3';

          this.isGenerating = false;

          // Send podcast to chat window
          this.sendToChat();
        } else if (data.type === 'error') {
          this.generatedContent = `❌ Error generating podcast: ${data.message}`;
          this.isGenerating = false;
        }
      },
      error: (error) => {
        console.error('Error generating podcast:', error);
        this.generatedContent = `❌ Error generating podcast: ${error.message || 'Unknown error occurred'}`;
        this.isGenerating = false;
      }
    });
  }

  private base64ToBlob(base64: string, contentType: string): Blob {
    const byteCharacters = atob(base64);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    return new Blob(byteArrays, { type: contentType });
  }
}
