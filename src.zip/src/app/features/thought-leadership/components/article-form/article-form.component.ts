import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from '../../../../shared/components/file-upload/file-upload.component';

@Component({
  selector: 'app-article-form',
  standalone: true,
  imports: [CommonModule, FormsModule, FileUploadComponent],
  templateUrl: './article-form.component.html',
  styleUrls: ['./article-form.component.scss']
})
export class ArticleFormComponent {
  @Output() submit = new EventEmitter<any>();
  
  topic: string = '';
  wordCount: number = 1000;
  tone: string = 'professional';
  referenceFiles: File[] = [];
  referenceLinks: string = '';

  onFileSelected(file: File): void {
    this.referenceFiles.push(file);
  }

  onFileRemoved(): void {
    this.referenceFiles = [];
  }

  onSubmit(): void {
    if (this.topic.trim()) {
      this.submit.emit({
        topic: this.topic,
        wordCount: this.wordCount,
        tone: this.tone,
        referenceFiles: this.referenceFiles,
        referenceLinks: this.referenceLinks
      });
    }
  }
}
