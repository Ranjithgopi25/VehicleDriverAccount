import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { GuidedDialogComponent } from '../../../shared/components/guided-dialog/guided-dialog.component';

type ContentFormat = 'article' | 'blog' | 'white-paper' | 'executive-brief' | 'social-media' | '';

interface FormatForm {
  sourceFormat: ContentFormat;
  targetFormat: ContentFormat;
  contentToTranslate: string;
  uploadedFile: File | null;
}

@Component({
  selector: 'app-format-translator-flow',
  standalone: true,
  imports: [CommonModule, FormsModule, GuidedDialogComponent],
  templateUrl: './format-translator-flow.component.html',
  styleUrls: ['./format-translator-flow.component.scss']
})
export class FormatTranslatorFlowComponent implements OnInit {
  currentStep: number = 1;
  totalSteps: number = 3;
  isGenerating: boolean = false;
  translatedContent: string = '';
  
  formData: FormatForm = {
    sourceFormat: '',
    targetFormat: '',
    contentToTranslate: '',
    uploadedFile: null
  };
  
  fileReadError: string = '';

  formats = [
    { id: 'article' as ContentFormat, name: 'Article', icon: '📄', description: '2,000-3,000 words, in-depth' },
    { id: 'blog' as ContentFormat, name: 'Blog Post', icon: '✍️', description: '800-1,500 words, conversational' },
    { id: 'white-paper' as ContentFormat, name: 'White Paper', icon: '📊', description: '5,000+ words, research-driven' },
    { id: 'executive-brief' as ContentFormat, name: 'Executive Brief', icon: '📋', description: '500-1,000 words, summary' },
    { id: 'social-media' as ContentFormat, name: 'Social Media', icon: '📱', description: 'Short-form, engaging' }
  ];

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {}

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'format-translator';
  }

  onClose(): void {
    this.resetForm();
    this.tlFlowService.closeFlow();
  }

  resetForm(): void {
    this.currentStep = 1;
    this.isGenerating = false;
    this.translatedContent = '';
    this.fileReadError = '';
    this.formData = {
      sourceFormat: '',
      targetFormat: '',
      contentToTranslate: '',
      uploadedFile: null
    };
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  previousStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  canProceed(): boolean {
    switch (this.currentStep) {
      case 1:
        return this.formData.sourceFormat !== '' && this.formData.targetFormat !== '' && this.formData.sourceFormat !== this.formData.targetFormat;
      case 2:
        return this.formData.contentToTranslate.trim().length > 0 || this.formData.uploadedFile !== null;
      default:
        return true;
    }
  }
  
  onFileSelect(event: any): void {
    const file = event.target.files?.[0];
    if (file) {
      this.formData.uploadedFile = file;
      this.formData.contentToTranslate = ''; // Clear textarea when file is selected
    }
  }

  selectSourceFormat(format: any): void {
    this.formData.sourceFormat = format as ContentFormat;
  }

  selectTargetFormat(format: any): void {
    this.formData.targetFormat = format as ContentFormat;
  }

  getFormatName(formatId: string): string {
    const format = this.formats.find(f => f.id === formatId);
    return format ? format.name : '';
  }

  async translateFormat(): Promise<void> {
    this.isGenerating = true;
    this.currentStep = 3;
    this.fileReadError = '';
    
    let contentText = this.formData.contentToTranslate;
    
    // Extract text from uploaded file if present
    if (this.formData.uploadedFile) {
      try {
        const extractedText = await this.extractFileText(this.formData.uploadedFile);
        contentText = extractedText;
      } catch (error) {
        console.error('Error extracting file:', error);
        this.fileReadError = 'Error reading uploaded file. Please try again.';
        this.isGenerating = false;
        return;
      }
    }
    
    const sourceFormatName = this.getFormatName(this.formData.sourceFormat);
    const targetFormatName = this.getFormatName(this.formData.targetFormat);
    
    let contentMessage = `Please convert this content from ${sourceFormatName} format to ${targetFormatName} format.`;
    contentMessage += `\n\nMaintain the strategic messaging while adapting the structure, length, and tone to match the target format's conventions.`;
    contentMessage += `\n\nSource Format: ${sourceFormatName}`;
    contentMessage += `\nTarget Format: ${targetFormatName}`;
    contentMessage += `\n\nContent to Convert:\n${contentText}`;
    
    const messages = [{
      role: 'user' as const,
      content: contentMessage
    }];

    this.chatService.streamFormatTranslator(messages).subscribe({
      next: (data: any) => {
        if (typeof data === 'string') {
          this.translatedContent += data;
        } else if (data.type === 'content' && data.content) {
          this.translatedContent += data.content;
        }
      },
      error: (error: any) => {
        console.error('Error translating format:', error);
        this.translatedContent = 'Sorry, there was an error translating your content. Please try again.';
        this.isGenerating = false;
      },
      complete: () => {
        this.isGenerating = false;
      }
    });
  }
  
  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/extract-text', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }
    
    const data = await response.json();
    return data.text || '';
  }

  downloadContent(format: 'txt' | 'docx'): void {
    const blob = new Blob([this.translatedContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `translated-content.${format}`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  copyToClipboard(): void {
    navigator.clipboard.writeText(this.translatedContent);
  }
}
