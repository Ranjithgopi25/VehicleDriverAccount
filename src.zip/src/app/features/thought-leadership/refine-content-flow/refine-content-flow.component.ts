import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { GuidedDialogComponent } from '../../../shared/components/guided-dialog/guided-dialog.component';

type RefineServiceType = 'expand-compress' | 'tone-audience' | 'research-enhancement' | 'editorial' | 'suggestions' | '';

interface RefineForm {
  serviceType: RefineServiceType;
  contentToRefine: string;
  refineParameters: string;
  uploadedFile: File | null;
}

@Component({
  selector: 'app-refine-content-flow',
  standalone: true,
  imports: [CommonModule, FormsModule, GuidedDialogComponent],
  templateUrl: './refine-content-flow.component.html',
  styleUrls: ['./refine-content-flow.component.scss']
})
export class RefineContentFlowComponent implements OnInit {
  currentStep: number = 1;
  totalSteps: number = 4;
  isGenerating: boolean = false;
  refinedContent: string = '';
  
  formData: RefineForm = {
    serviceType: '',
    contentToRefine: '',
    refineParameters: '',
    uploadedFile: null
  };
  
  fileReadError: string = '';

  services = [
    { id: 'expand-compress' as RefineServiceType, name: 'Expand/Compress Content', icon: '📏', description: 'Adjust content length while preserving key messages' },
    { id: 'tone-audience' as RefineServiceType, name: 'Adjust Tone/Audience', icon: '🎭', description: 'Change tone or adapt for different audiences' },
    { id: 'research-enhancement' as RefineServiceType, name: 'Research Enhancement', icon: '🔬', description: 'Add research, data, and citations' },
    { id: 'editorial' as RefineServiceType, name: 'Editorial Support', icon: '✨', description: 'Overall content improvement and polish' },
    { id: 'suggestions' as RefineServiceType, name: 'Improvement Suggestions', icon: '💡', description: 'Get strategic recommendations for enhancement' }
  ];

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {}

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'refine-content';
  }

  onClose(): void {
    this.resetForm();
    this.tlFlowService.closeFlow();
  }

  resetForm(): void {
    this.currentStep = 1;
    this.isGenerating = false;
    this.refinedContent = '';
    this.fileReadError = '';
    this.formData = {
      serviceType: '',
      contentToRefine: '',
      refineParameters: '',
      uploadedFile: null
    };
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  previousStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  canProceed(): boolean {
    switch (this.currentStep) {
      case 1:
        return this.formData.serviceType !== '';
      case 2:
        return this.formData.contentToRefine.trim().length > 0 || this.formData.uploadedFile !== null;
      case 3:
        return true; // Parameters are optional
      default:
        return true;
    }
  }
  
  onFileSelect(event: any): void {
    const file = event.target.files?.[0];
    if (file) {
      this.formData.uploadedFile = file;
      this.formData.contentToRefine = ''; // Clear textarea when file is selected
    }
  }

  selectServiceType(type: any): void {
    this.formData.serviceType = type as RefineServiceType;
  }

  getServiceName(): string {
    const service = this.services.find(s => s.id === this.formData.serviceType);
    return service ? service.name : '';
  }

  async refineContent(): Promise<void> {
    this.isGenerating = true;
    this.currentStep = 4;
    this.fileReadError = '';
    
    let contentText = this.formData.contentToRefine;
    
    // Extract text from uploaded file if present
    if (this.formData.uploadedFile) {
      try {
        const extractedText = await this.extractFileText(this.formData.uploadedFile);
        contentText = extractedText;
      } catch (error) {
        console.error('Error extracting file:', error);
        this.fileReadError = 'Error reading uploaded file. Please try again.';
        this.isGenerating = false;
        return;
      }
    }
    
    const serviceName = this.getServiceName();
    let instruction = '';
    
    switch (this.formData.serviceType) {
      case 'expand-compress':
        instruction = 'adjust the length of';
        break;
      case 'tone-audience':
        instruction = 'adjust the tone/audience for';
        break;
      case 'research-enhancement':
        instruction = 'enhance with research';
        break;
      case 'editorial':
        instruction = 'provide editorial improvements for';
        break;
      default:
        instruction = 'suggest improvements for';
    }
    
    let contentMessage = `Please ${instruction} the following content using the ${serviceName} service.`;
    
    if (this.formData.refineParameters) {
      contentMessage += `\n\nSpecific Parameters: ${this.formData.refineParameters}`;
    }
    
    contentMessage += `\n\nContent to Refine:\n${contentText}`;
    
    const messages = [{
      role: 'user' as const,
      content: contentMessage
    }];

    this.chatService.streamRefineContent(messages).subscribe({
      next: (data: any) => {
        if (typeof data === 'string') {
          this.refinedContent += data;
        } else if (data.type === 'content' && data.content) {
          this.refinedContent += data.content;
        }
      },
      error: (error: any) => {
        console.error('Error refining content:', error);
        this.refinedContent = 'Sorry, there was an error refining your content. Please try again.';
        this.isGenerating = false;
      },
      complete: () => {
        this.isGenerating = false;
      }
    });
  }
  
  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/extract-text', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }
    
    const data = await response.json();
    return data.text || '';
  }

  downloadContent(format: 'txt' | 'docx'): void {
    const blob = new Blob([this.refinedContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `refined-content.${format}`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  copyToClipboard(): void {
    navigator.clipboard.writeText(this.refinedContent);
  }
}
