import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TlFlowService } from '../../../core/services/tl-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { GuidedDialogComponent } from '../../../shared/components/guided-dialog/guided-dialog.component';
import { SourceCitationPipe, Nl2brPipe } from '../../../core/pipes';
import { Source } from '../../../core/models/message.model';

interface ResearchForm {
  researchQuestion: string;
  uploadedFiles: File[];
  urls: string;
  selectedPwcResources: string[];
  selectedThirdPartyTools: string[];
  useUploadedContent: boolean;
  useLicensedTools: boolean;
  usePwcResearch: boolean;
  useExternalResearch: boolean;
  selectSpecificPwcSources: boolean;
  pwcProprietaryResearch: boolean;
  allSources: boolean;
  additionalGuidelines: string;
}

@Component({
  selector: 'app-conduct-research-flow',
  standalone: true,
  imports: [CommonModule, FormsModule, GuidedDialogComponent, SourceCitationPipe, Nl2brPipe],
  templateUrl: './conduct-research-flow.component.html',
  styleUrls: ['./conduct-research-flow.component.scss']
})
export class ConductResearchFlowComponent implements OnInit {
  isGenerating: boolean = false;
  researchResults: string = '';
  fileReadError: string = '';
  researchSources: Source[] = [];
  showResults: boolean = false;
  showPwcSourceList: boolean = false;
  showExternalSourceList: boolean = false;
  
  formData: ResearchForm = {
    researchQuestion: '',
    uploadedFiles: [],
    urls: '',
    selectedPwcResources: [],
    selectedThirdPartyTools: [],
    useUploadedContent: true,
    useLicensedTools: false,
    usePwcResearch: true,
    useExternalResearch: true,
    selectSpecificPwcSources: false,
    pwcProprietaryResearch: false,
    allSources: false,
    additionalGuidelines: ''
  };

  pwcResources = [
    'Dealogic', 'Capital IQ', 'FactSet', 'PitchBook', 'Preqin',
    'Refinitiv', 'CB Insights', 'Crunchbase', 'PwC Research Library',
    'Industry Benchmarking Database', 'PwC Deal Analytics', 'Market Intelligence Platform',
    'Regulatory Database', 'Tax Research Platform', 'PwC Knowledge Center'
  ];

  thirdPartyTools = [
    'Bloomberg Terminal', 'Thomson Reuters Eikon', 'S&P Global Market Intelligence',
    'Moody\'s Analytics', 'Fitch Solutions', 'Gartner Research', 'Forrester Research',
    'IDC Research', 'Statista', 'IBISWorld', 'Euromonitor', 'MarketResearch.com',
    'Frost & Sullivan', 'Grand View Research', 'Allied Market Research',
    'McKinsey Global Institute', 'BCG Henderson Institute', 'Bain & Company Insights',
    'Deloitte Insights', 'KPMG Research'
  ];

  constructor(
    public tlFlowService: TlFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {}

  get isOpen(): boolean {
    return this.tlFlowService.currentFlow === 'conduct-research';
  }

  onClose(): void {
    this.resetForm();
    this.tlFlowService.closeFlow();
  }

  resetForm(): void {
    this.isGenerating = false;
    this.researchResults = '';
    this.researchSources = [];
    this.showResults = false;
    this.showPwcSourceList = false;
    this.showExternalSourceList = false;
    this.formData = {
      researchQuestion: '',
      uploadedFiles: [],
      urls: '',
      selectedPwcResources: [],
      selectedThirdPartyTools: [],
      useUploadedContent: true,
      useLicensedTools: false,
      usePwcResearch: true,
      useExternalResearch: true,
      selectSpecificPwcSources: false,
      pwcProprietaryResearch: false,
      allSources: false,
      additionalGuidelines: ''
    };
  }

  canGenerateResearch(): boolean {
    return this.formData.researchQuestion.trim().length > 0;
  }

  backToForm(): void {
    this.showResults = false;
  }

  onToggleChange(): void {
    if (!this.formData.usePwcResearch && !this.formData.useLicensedTools) {
      this.formData.selectSpecificPwcSources = false;
      this.formData.selectedPwcResources = [];
      this.formData.selectedThirdPartyTools = [];
    }
  }

  onSpecificSourcesChange(): void {
    if (!this.formData.selectSpecificPwcSources) {
      this.formData.pwcProprietaryResearch = false;
      this.formData.allSources = false;
      this.showPwcSourceList = false;
      this.showExternalSourceList = false;
    }
  }

  togglePwcSourceList(): void {
    this.showPwcSourceList = !this.showPwcSourceList;
  }

  toggleExternalSourceList(): void {
    this.showExternalSourceList = !this.showExternalSourceList;
  }

  removeFile(file: File): void {
    const index = this.formData.uploadedFiles.indexOf(file);
    if (index > -1) {
      this.formData.uploadedFiles.splice(index, 1);
    }
  }

  onFileSelect(event: any): void {
    const newFiles = Array.from(event.target.files) as File[];
    
    for (const newFile of newFiles) {
      const isDuplicate = this.formData.uploadedFiles.some(
        existing => existing.name === newFile.name && existing.size === newFile.size
      );
      
      if (!isDuplicate) {
        this.formData.uploadedFiles.push(newFile);
      }
    }
    
    event.target.value = '';
  }

  togglePwcResource(resource: string): void {
    const index = this.formData.selectedPwcResources.indexOf(resource);
    if (index > -1) {
      this.formData.selectedPwcResources.splice(index, 1);
    } else {
      this.formData.selectedPwcResources.push(resource);
    }
  }

  toggleThirdPartyTool(tool: string): void {
    const index = this.formData.selectedThirdPartyTools.indexOf(tool);
    if (index > -1) {
      this.formData.selectedThirdPartyTools.splice(index, 1);
    } else {
      this.formData.selectedThirdPartyTools.push(tool);
    }
  }

  isPwcResourceSelected(resource: string): boolean {
    return this.formData.selectedPwcResources.includes(resource);
  }

  isThirdPartyToolSelected(tool: string): boolean {
    return this.formData.selectedThirdPartyTools.includes(tool);
  }

  async conductResearch(): Promise<void> {
    this.isGenerating = true;
    this.showResults = true;
    this.fileReadError = '';
    this.researchResults = '';
    
    let contentMessage = `Generate a comprehensive business article on: ${this.formData.researchQuestion}. Write a professional, publication-ready article with clear sections, data-driven insights, and inline citations [1.], [2.], etc.`;
    
    if (this.formData.additionalGuidelines) {
      contentMessage += `\n\nAdditional Guidelines: ${this.formData.additionalGuidelines}`;
    }
    
    if (this.formData.useUploadedContent && this.formData.urls) {
      contentMessage += `\n\nReference URLs: ${this.formData.urls}`;
    }
    
    if (this.formData.useUploadedContent && this.formData.uploadedFiles && this.formData.uploadedFiles.length > 0) {
      contentMessage += `\n\nUploaded Documents (${this.formData.uploadedFiles.length} files):`;
      for (const file of this.formData.uploadedFiles) {
        try {
          let fileContent = '';
          
          if (this.isTextFile(file)) {
            fileContent = await this.readFileContent(file);
          } else if (file.name.toLowerCase().endsWith('.pdf') || file.name.toLowerCase().endsWith('.docx')) {
            fileContent = await this.extractFileText(file);
          } else {
            this.fileReadError += `\nWarning: Skipped ${file.name} (unsupported format). Supported: PDF, DOCX, TXT, MD`;
            continue;
          }
          
          contentMessage += `\n\n--- ${file.name} ---\n${fileContent.substring(0, 8000)}`;
        } catch (error) {
          console.error(`Error reading file ${file.name}:`, error);
          this.fileReadError += `\nError reading ${file.name}. Please try re-uploading.`;
        }
      }
    }
    
    if (this.formData.selectedPwcResources.length > 0 || this.formData.selectedThirdPartyTools.length > 0) {
      contentMessage += '\n\nNote: The following resources are currently in development and will be integrated soon:';
      if (this.formData.selectedPwcResources.length > 0) {
        contentMessage += `\nPwC Resources: ${this.formData.selectedPwcResources.join(', ')}`;
      }
      if (this.formData.selectedThirdPartyTools.length > 0) {
        contentMessage += `\nThird-Party Tools: ${this.formData.selectedThirdPartyTools.join(', ')}`;
      }
    }
    
    const messages = [{
      role: 'user' as const,
      content: contentMessage
    }];

    const sourceGroups: string[] = [];
    if (this.formData.usePwcResearch && this.formData.selectedPwcResources.length > 0) {
      sourceGroups.push('PwC Proprietary');
    }
    if (this.formData.useLicensedTools && this.formData.selectedThirdPartyTools.length > 0) {
      sourceGroups.push('PwC Licensed');
    }
    if (this.formData.useExternalResearch) {
      sourceGroups.push('External Research');
    }

    this.chatService.streamConductResearch(messages, sourceGroups.length > 0 ? sourceGroups : undefined).subscribe({
      next: (data: any) => {
        if (typeof data === 'string') {
          this.researchResults += data;
        } else if (data.type === 'content' && data.content) {
          this.researchResults += data.content;
        } else if (data.type === 'sources' && data.sources) {
          this.researchSources = data.sources;
        }
      },
      error: (error: any) => {
        console.error('Error conducting research:', error);
        this.researchResults = 'Sorry, there was an error conducting your research. Please try again.';
        this.isGenerating = false;
      },
      complete: () => {
        this.isGenerating = false;
      }
    });
  }

  private isTextFile(file: File): boolean {
    const textExtensions = ['.txt', '.md', '.markdown', '.text', '.csv', '.json', '.xml', '.html', '.htm'];
    const fileName = file.name.toLowerCase();
    return textExtensions.some(ext => fileName.endsWith(ext)) || 
           file.type.startsWith('text/');
  }

  private readFileContent(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        resolve(content || '');
      };
      reader.onerror = reject;
      reader.readAsText(file);
    });
  }

  downloadResults(format: 'txt' | 'docx' | 'pdf'): void {
    const blob = new Blob([this.researchResults], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `research-results.${format}`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  copyToClipboard(): void {
    navigator.clipboard.writeText(this.researchResults);
  }
  
  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/extract-text', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }
    
    const data = await response.json();
    return data.text || '';
  }
}
