import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';

@Component({
  selector: 'app-slide-creation-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './slide-creation-flow.component.html',
  styleUrls: ['./slide-creation-flow.component.scss']
})
export class SlideCreationFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  currentStep = 1;
  totalSteps = 3;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFiles: File[] = [];
  slideTemplate: string = 'pwc-standard';
  numberOfSlides: number = 5;
  customInstructions: string = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'slide-creation';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SlideCreationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.currentStep = 1;
    this.uploadedFiles = [];
    this.slideTemplate = 'pwc-standard';
    this.numberOfSlides = 5;
    this.customInstructions = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFilesSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFiles = Array.from(input.files);
    }
  }

  removeFile(index: number): void {
    this.uploadedFiles.splice(index, 1);
  }

  get canProceedFromStep1(): boolean {
    return this.uploadedFiles.length > 0;
  }

  get canProceedFromStep2(): boolean {
    return this.numberOfSlides > 0;
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (this.uploadedFiles.length === 0) return;

    try {
      this.isGenerating = true;
      this.generatedContent = '';
      this.currentStep = 3;

      const formData = new FormData();
      this.uploadedFiles.forEach((file, index) => {
        formData.append(`file_${index}`, file);
      });
      formData.append('template', this.slideTemplate);
      formData.append('num_slides', this.numberOfSlides.toString());
      formData.append('instructions', this.customInstructions);

      console.log('[SlideCreationFlow] Sending request');

      this.streamSubscription = this.chatService.streamDdcSlideCreation(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[SlideCreationFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[SlideCreationFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[SlideCreationFlow] Exception:', error);
      this.isGenerating = false;
    }
  }
}
