import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';

@Component({
  selector: 'app-ddc-format-translator-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './format-translator-flow.component.html',
  styleUrls: ['./format-translator-flow.component.scss']
})
export class FormatTranslatorFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  currentStep = 1;
  totalSteps = 3;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  targetFormat: string = 'case-study';
  includeVisuals: boolean = true;
  tone: string = 'professional';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'ddc-format-translator';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[FormatTranslatorFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.currentStep = 1;
    this.uploadedFile = null;
    this.targetFormat = 'case-study';
    this.includeVisuals = true;
    this.tone = 'professional';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
  }

  get canProceedFromStep1(): boolean {
    return this.uploadedFile !== null;
  }

  get canProceedFromStep2(): boolean {
    return true;
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) return;

    try {
      this.isGenerating = true;
      this.generatedContent = '';
      this.currentStep = 3;

      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('target_format', this.targetFormat);
      formData.append('include_visuals', this.includeVisuals.toString());
      formData.append('tone', this.tone);

      console.log('[FormatTranslatorFlow] Sending request');

      this.streamSubscription = this.chatService.streamDdcFormatTranslator(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[FormatTranslatorFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[FormatTranslatorFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[FormatTranslatorFlow] Exception:', error);
      this.isGenerating = false;
    }
  }
}
