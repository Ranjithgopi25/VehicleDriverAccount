import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';
import { FileUploadComponent } from '../../../shared/ui/components/file-upload/file-upload.component';
import { ToggleSwitchComponent } from '../../../shared/ui/components/toggle-switch/toggle-switch.component';

interface SubService {
  id: string;
  label: string;
  enabled: boolean;
}

interface BrandingService {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
  showSubServices: boolean;
  subServices: SubService[];
}

@Component({
  selector: 'app-brand-format-flow',
  standalone: true,
  imports: [CommonModule, FormsModule, FileUploadComponent, ToggleSwitchComponent],
  templateUrl: './brand-format-flow.component.html',
  styleUrls: ['./brand-format-flow.component.scss']
})
export class BrandFormatFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  selectedTemplate = '';
  customTemplateFile: File | null = null;
  
  alignToPwC = true;
  additionalGuidelines = '';
  
  brandingServices: BrandingService[] = [
    {
      id: 'format-bullets',
      label: 'Format Bullets Using Presentation Best Practices',
      description: 'Apply PwC best practices for bullet formatting',
      enabled: true,
      showSubServices: false,
      subServices: [
        { id: 'bullets-consistency', label: 'Bullets Consistency', enabled: true },
        { id: 'type-of-bullets', label: 'Type of bullets', enabled: true },
        { id: 'use-of-periods', label: 'Use of Periods', enabled: true },
        { id: 'one-statement', label: 'No More than One Statement', enabled: true }
      ]
    },
    {
      id: 'standardize-layout',
      label: 'Standardize the Layout and Space of all Elements (e.g., text boxes, shapes, icons)',
      description: 'Ensure consistent spacing and alignment',
      enabled: false,
      showSubServices: false,
      subServices: [
        { id: 'text-box-alignment', label: 'Text Box Alignment', enabled: true },
        { id: 'shape-positioning', label: 'Shape Positioning', enabled: true },
        { id: 'icon-spacing', label: 'Icon Spacing', enabled: true },
        { id: 'margin-consistency', label: 'Margin Consistency', enabled: true }
      ]
    },
    {
      id: 'charts-styling',
      label: 'Apply Consistent Styling and Colors to Charts',
      description: 'Standardize chart appearance',
      enabled: false,
      showSubServices: false,
      subServices: [
        { id: 'chart-colors', label: 'Chart Color Palette', enabled: true },
        { id: 'chart-fonts', label: 'Chart Font Consistency', enabled: true },
        { id: 'legend-position', label: 'Legend Positioning', enabled: true },
        { id: 'data-labels', label: 'Data Label Formatting', enabled: true }
      ]
    },
    {
      id: 'font-consistency',
      label: 'Ensure Consistency in Fonts, Spacing etc. Throughout',
      description: 'Apply uniform font and spacing standards',
      enabled: false,
      showSubServices: false,
      subServices: [
        { id: 'font-family', label: 'Font Family Standardization', enabled: true },
        { id: 'font-sizes', label: 'Font Size Hierarchy', enabled: true },
        { id: 'line-spacing', label: 'Line Spacing', enabled: true },
        { id: 'paragraph-spacing', label: 'Paragraph Spacing', enabled: true }
      ]
    },
    {
      id: 'improve-clarity',
      label: 'Improve Clarity and Finalize Document (e.g., removing jargon, testing embedded links)',
      description: 'Polish and refine content quality',
      enabled: false,
      showSubServices: false,
      subServices: [
        { id: 'jargon-removal', label: 'Remove Excessive Jargon', enabled: true },
        { id: 'link-validation', label: 'Test Embedded Links', enabled: true },
        { id: 'readability', label: 'Improve Readability', enabled: true },
        { id: 'consistency-check', label: 'Final Consistency Check', enabled: true }
      ]
    }
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'brand-format';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[BrandFormatFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = '';
    this.customTemplateFile = null;
    this.alignToPwC = true;
    this.additionalGuidelines = '';
    this.brandingServices[0].enabled = true;
    this.brandingServices[0].showSubServices = false;
    for (let i = 1; i < this.brandingServices.length; i++) {
      this.brandingServices[i].enabled = false;
      this.brandingServices[i].showSubServices = false;
    }
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onTemplateFileSelected(file: File): void {
    this.customTemplateFile = file;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get needsCustomTemplate(): boolean {
    return this.selectedTemplate === 'client-specific' || this.selectedTemplate === 'other';
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (this.needsCustomTemplate && !this.customTemplateFile) return false;
    return this.brandingServices.some(s => s.enabled);
  }

  get selectedServices(): BrandingService[] {
    return this.brandingServices.filter(s => s.enabled);
  }

  onServiceToggle(service: BrandingService): void {
    if (!service.enabled) {
      service.showSubServices = false;
    }
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) {
      console.error('No file uploaded');
      return;
    }

    this.isGenerating = true;
    this.generatedContent = '';

    try {
      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('template', this.selectedTemplate);
      
      if (this.customTemplateFile) {
        formData.append('template_file', this.customTemplateFile);
      }
      
      formData.append('align_to_pwc', String(this.alignToPwC));
      formData.append('additional_guidelines', this.additionalGuidelines);
      
      const servicesConfig = this.selectedServices.map(s => ({
        id: s.id,
        label: s.label,
        subServices: s.showSubServices 
          ? s.subServices.filter(sub => sub.enabled).map(sub => ({ id: sub.id, label: sub.label }))
          : []
      }));
      
      formData.append('services', JSON.stringify(servicesConfig));

      console.log('[BrandFormatFlow] Sending request:', {
        fileName: this.uploadedFile.name,
        template: this.selectedTemplate,
        hasCustomTemplate: !!this.customTemplateFile,
        alignToPwC: this.alignToPwC,
        services: servicesConfig
      });

      this.streamSubscription = this.chatService.streamDdcBrandFormat(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[BrandFormatFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error processing your presentation. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[BrandFormatFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[BrandFormatFlow] Exception:', error);
      this.isGenerating = false;
    }
  }

  downloadProcessedFile(): void {
    console.log('[BrandFormatFlow] Download triggered');
  }
}
