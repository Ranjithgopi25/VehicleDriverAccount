import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';

interface SanitizationService {
  id: string;
  label: string;
  selected: boolean;
}

@Component({
  selector: 'app-sanitization-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './sanitization-flow.component.html',
  styleUrls: ['./sanitization-flow.component.scss']
})
export class SanitizationFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  isGenerating = false;
  generatedContent = '';
  
  // Form fields
  uploadedFile: File | null = null;
  selectedTemplate: string = 'core';
  customTemplateFile: File | null = null;
  clientIdentifiers: string = '';
  additionalGuidelines: string = '';
  
  // Sanitization services (4 default-checked)
  sanitizationServices: SanitizationService[] = [
    { id: 'convert_template', label: 'Convert to a PwC Standard Template', selected: true },
    { id: 'crop_thumbnails', label: 'Crop Identifying Information Out of Thumbnails', selected: true },
    { id: 'replace_client', label: 'Replace Client Name and Logos', selected: true },
    { id: 'delete_notes', label: 'Delete Notes / Comments', selected: true },
    { id: 'anonymize_products', label: 'Anonymize Product Names', selected: false },
    { id: 'cut_hyperlinks', label: 'Cut Hyperlinks', selected: false },
    { id: 'mask_leadership', label: 'Mask Leadership/Employee Names or Client-Identifying Titles', selected: false },
    { id: 'paste_as_pictures', label: 'Paste all Charts/Graphs as Pictures', selected: false },
    { id: 'change_competitors', label: 'Change Competitor Names, Logos, and Product Names', selected: false },
    { id: 'remove_data', label: 'Remove Client-specific Data (e.g., Financials, FTEs, Ops. Metrics)', selected: false },
    { id: 'conceal_regions', label: 'Conceal Client-identifying Regions and Locations', selected: false },
    { id: 'disguise_bus', label: 'Disguise Client-identifying BUs', selected: false }
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'sanitization';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[SanitizationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.uploadedFile = null;
    this.selectedTemplate = 'core';
    this.customTemplateFile = null;
    this.clientIdentifiers = '';
    this.additionalGuidelines = '';
    this.sanitizationServices.forEach((service, index) => {
      // First 4 services default to checked
      service.selected = index < 4;
    });
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  onTemplateFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.customTemplateFile = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
  }

  removeTemplateFile(): void {
    this.customTemplateFile = null;
  }

  get canGenerate(): boolean {
    if (!this.uploadedFile) return false;
    if (this.selectedTemplate === 'other' && !this.customTemplateFile) return false;
    return this.sanitizationServices.some(s => s.selected);
  }

  get selectedServices(): SanitizationService[] {
    return this.sanitizationServices.filter(s => s.selected);
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (!this.canGenerate) return;

    try {
      this.isGenerating = true;
      this.generatedContent = 'Sanitizing your presentation... This may take a moment.';

      const formData = new FormData();
      formData.append('file', this.uploadedFile!);
      formData.append('template', this.selectedTemplate);
      if (this.customTemplateFile) {
        formData.append('custom_template', this.customTemplateFile);
      }
      formData.append('client_identifiers', this.clientIdentifiers);
      formData.append('services', JSON.stringify(this.selectedServices.map(s => s.id)));
      formData.append('additional_guidelines', this.additionalGuidelines);

      console.log('[SanitizationFlow] Sending request with', this.selectedServices.length, 'services');

      // Call the backend to sanitize and download the file
      const response = await fetch('/api/ddc/sanitization', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error(`Sanitization failed: ${response.statusText}`);
      }

      // Get the sanitized file
      const blob = await response.blob();
      const filename = this.uploadedFile!.name.replace('.pptx', '_sanitized.pptx');

      // Download the file
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      // Show success message
      this.generatedContent = `✅ Sanitization complete! ${this.selectedServices.length} service(s) applied.\n\nYour sanitized presentation "${filename}" has been downloaded.\n\nServices applied:\n${this.selectedServices.map(s => `  • ${s.label}`).join('\n')}`;
      this.isGenerating = false;

      console.log('[SanitizationFlow] Sanitization and download complete');
    } catch (error) {
      console.error('[SanitizationFlow] Exception:', error);
      this.generatedContent = '❌ I apologize, but I encountered an error during sanitization. Please try again.';
      this.isGenerating = false;
    }
  }
}
