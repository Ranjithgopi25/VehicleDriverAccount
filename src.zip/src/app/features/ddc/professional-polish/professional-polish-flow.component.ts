import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';

interface PolishService {
  id: string;
  label: string;
  description: string;
  selected: boolean;
}

@Component({
  selector: 'app-professional-polish-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './professional-polish-flow.component.html',
  styleUrls: ['./professional-polish-flow.component.scss']
})
export class ProfessionalPolishFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  currentStep = 1;
  totalSteps = 3;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  
  polishServices: PolishService[] = [
    { id: 'grammar', label: 'Grammar & Spelling Check', description: 'Fix grammar and spelling errors', selected: true },
    { id: 'visual', label: 'Visual Enhancement', description: 'Improve charts and alignment', selected: true },
    { id: 'language', label: 'Language Quality', description: 'Enhance clarity and professionalism', selected: true },
    { id: 'consistency', label: 'Consistency Check', description: 'Ensure consistent formatting', selected: true }
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'professional-polish';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[ProfessionalPolishFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.currentStep = 1;
    this.uploadedFile = null;
    this.polishServices.forEach(service => service.selected = true);
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
  }

  get canProceedFromStep1(): boolean {
    return this.uploadedFile !== null;
  }

  get canProceedFromStep2(): boolean {
    return this.polishServices.some(s => s.selected);
  }

  get selectedServices(): PolishService[] {
    return this.polishServices.filter(s => s.selected);
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) return;

    try {
      this.isGenerating = true;
      this.generatedContent = '';
      this.currentStep = 3;

      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('services', JSON.stringify(this.selectedServices.map(s => s.id)));

      console.log('[ProfessionalPolishFlow] Sending request');

      this.streamSubscription = this.chatService.streamDdcProfessionalPolish(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[ProfessionalPolishFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[ProfessionalPolishFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[ProfessionalPolishFlow] Exception:', error);
      this.isGenerating = false;
    }
  }
}
