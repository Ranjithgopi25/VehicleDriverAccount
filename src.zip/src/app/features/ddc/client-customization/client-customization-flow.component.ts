import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';

interface CustomizationOption {
  id: string;
  label: string;
  description: string;
  selected: boolean;
}

@Component({
  selector: 'app-client-customization-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './client-customization-flow.component.html',
  styleUrls: ['./client-customization-flow.component.scss']
})
export class ClientCustomizationFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  currentStep = 1;
  totalSteps = 3;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  clientName: string = '';
  clientLogo: File | null = null;
  primaryColor: string = '#D04A02';
  secondaryColor: string = '#000000';
  
  customizationOptions: CustomizationOption[] = [
    { id: 'branding', label: 'Replace Branding', description: 'Update logos and brand elements', selected: true },
    { id: 'colors', label: 'Update Color Scheme', description: 'Apply client color palette', selected: true },
    { id: 'messaging', label: 'Customize Messaging', description: 'Tailor messaging to client', selected: false }
  ];

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'client-customization';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[ClientCustomizationFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.currentStep = 1;
    this.uploadedFile = null;
    this.clientName = '';
    this.clientLogo = null;
    this.primaryColor = '#D04A02';
    this.secondaryColor = '#000000';
    this.customizationOptions.forEach((option, index) => option.selected = index < 2);
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  onLogoSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.clientLogo = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
  }

  removeLogo(): void {
    this.clientLogo = null;
  }

  get canProceedFromStep1(): boolean {
    return this.uploadedFile !== null;
  }

  get canProceedFromStep2(): boolean {
    return this.clientName.trim().length > 0 && this.customizationOptions.some(o => o.selected);
  }

  get selectedOptions(): CustomizationOption[] {
    return this.customizationOptions.filter(o => o.selected);
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile) return;

    try {
      this.isGenerating = true;
      this.generatedContent = '';
      this.currentStep = 3;

      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('client_name', this.clientName);
      if (this.clientLogo) {
        formData.append('client_logo', this.clientLogo);
      }
      formData.append('primary_color', this.primaryColor);
      formData.append('secondary_color', this.secondaryColor);
      formData.append('options', JSON.stringify(this.selectedOptions.map(o => o.id)));

      console.log('[ClientCustomizationFlow] Sending request');

      this.streamSubscription = this.chatService.streamDdcClientCustomization(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[ClientCustomizationFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[ClientCustomizationFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[ClientCustomizationFlow] Exception:', error);
      this.isGenerating = false;
    }
  }
}
