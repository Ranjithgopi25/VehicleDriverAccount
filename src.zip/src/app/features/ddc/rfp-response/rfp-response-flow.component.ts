import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { DdcFlowService } from '../../../core/services/ddc-flow.service';
import { ChatService } from '../../../core/services/chat.service';

@Component({
  selector: 'app-rfp-response-flow',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './rfp-response-flow.component.html',
  styleUrls: ['./rfp-response-flow.component.scss']
})
export class RfpResponseFlowComponent implements OnInit, OnDestroy {
  isOpen = false;
  currentStep = 1;
  totalSteps = 3;
  isGenerating = false;
  generatedContent = '';
  
  uploadedFile: File | null = null;
  rfpDocument: File | null = null;
  customInstructions: string = '';

  private destroy$ = new Subject<void>();
  private streamSubscription?: Subscription;

  constructor(
    private ddcFlowService: DdcFlowService,
    private chatService: ChatService
  ) {}

  ngOnInit(): void {
    this.ddcFlowService.activeFlow$
      .pipe(takeUntil(this.destroy$))
      .subscribe(flow => {
        this.isOpen = flow === 'rfp-response';
        if (this.isOpen) {
          this.resetForm();
        }
      });
  }

  ngOnDestroy(): void {
    this.cancelStream();
    this.destroy$.next();
    this.destroy$.complete();
  }

  private cancelStream(): void {
    if (this.streamSubscription) {
      console.log('[RfpResponseFlow] Cancelling active stream');
      this.streamSubscription.unsubscribe();
      this.streamSubscription = undefined;
      this.isGenerating = false;
    }
  }

  resetForm(): void {
    this.currentStep = 1;
    this.uploadedFile = null;
    this.rfpDocument = null;
    this.customInstructions = '';
    this.generatedContent = '';
    this.isGenerating = false;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.uploadedFile = input.files[0];
    }
  }

  onRfpSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.rfpDocument = input.files[0];
    }
  }

  removeFile(): void {
    this.uploadedFile = null;
  }

  removeRfp(): void {
    this.rfpDocument = null;
  }

  get canProceedFromStep1(): boolean {
    return this.uploadedFile !== null && this.rfpDocument !== null;
  }

  get canProceedFromStep2(): boolean {
    return true;
  }

  nextStep(): void {
    if (this.currentStep < this.totalSteps) {
      this.currentStep++;
    }
  }

  prevStep(): void {
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  close(): void {
    this.cancelStream();
    this.ddcFlowService.closeFlow();
  }

  async generate(): Promise<void> {
    if (!this.uploadedFile || !this.rfpDocument) return;

    try {
      this.isGenerating = true;
      this.generatedContent = '';
      this.currentStep = 3;

      const formData = new FormData();
      formData.append('file', this.uploadedFile);
      formData.append('rfp_document', this.rfpDocument);
      formData.append('instructions', this.customInstructions);

      console.log('[RfpResponseFlow] Sending request');

      this.streamSubscription = this.chatService.streamDdcRfpResponse(formData).subscribe({
        next: (chunk: string) => {
          this.generatedContent += chunk;
        },
        error: (error: Error) => {
          console.error('[RfpResponseFlow] Error:', error);
          this.generatedContent = 'I apologize, but I encountered an error. Please try again.';
          this.isGenerating = false;
          this.streamSubscription = undefined;
        },
        complete: () => {
          console.log('[RfpResponseFlow] Generation complete');
          this.isGenerating = false;
          this.streamSubscription = undefined;
        }
      });
    } catch (error) {
      console.error('[RfpResponseFlow] Exception:', error);
      this.isGenerating = false;
    }
  }
}
