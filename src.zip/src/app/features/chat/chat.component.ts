import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChatService, TlChatBridgeService, ChatEditWorkflowService } from '../../core/services';
import { TlFlowService } from '../../core/services/tl-flow.service';
import { DdcFlowService } from '../../core/services/ddc-flow.service';
import { Message, ChatSession } from '../../core/models';
import { JourneyType, TL_WORKFLOWS, DDC_WORKFLOWS, WorkflowCard } from '../../core/models/guided-journey.models';
import { MessageListComponent } from './components/message-list/message-list.component';
import { ChatInputComponent } from './components/chat-input/chat-input.component';
import { ChatHistorySidebarComponent } from './components/chat-history-sidebar/chat-history-sidebar.component';
import { WelcomeScreenComponent, QuickAction } from './components/welcome-screen/welcome-screen.component';
import { GuidedDialogComponent } from '../../shared/components/guided-dialog/guided-dialog.component';
import { DraftContentFlowComponent } from '../thought-leadership/draft-content-flow/draft-content-flow.component';
import { ConductResearchFlowComponent } from '../thought-leadership/conduct-research-flow/conduct-research-flow.component';
import { EditContentFlowComponent } from '../thought-leadership/edit-content-flow/edit-content-flow.component';
import { RefineContentFlowComponent } from '../thought-leadership/refine-content-flow/refine-content-flow.component';
import { FormatTranslatorFlowComponent } from '../thought-leadership/format-translator-flow/format-translator-flow.component';
import { GeneratePodcastFlowComponent } from '../thought-leadership/generate-podcast-flow/generate-podcast-flow.component';
import { BrandFormatFlowComponent } from '../ddc/brand-format-flow/brand-format-flow.component';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [
    CommonModule,
    MessageListComponent,
    ChatInputComponent,
    ChatHistorySidebarComponent,
    WelcomeScreenComponent,
    GuidedDialogComponent,
    DraftContentFlowComponent,
    ConductResearchFlowComponent,
    EditContentFlowComponent,
    RefineContentFlowComponent,
    FormatTranslatorFlowComponent,
    GeneratePodcastFlowComponent,
    BrandFormatFlowComponent
  ],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit, OnDestroy {
  @ViewChild(MessageListComponent) messageList?: MessageListComponent;

  messages: Message[] = [];
  userInput: string = '';
  isLoading: boolean = false;
  uploadedFile: File | null = null;
  
  // Chat history
  currentSessionId: string | null = null;
  savedSessions: ChatSession[] = [];
  showHistoryPanel: boolean = false;
  searchQuery: string = '';
  
  // Guided dialogs
  showGuidedDialog: boolean = false;
  currentJourney: JourneyType | null = null;
  currentWorkflows: WorkflowCard[] = [];
  
  private readonly STORAGE_KEY = 'pwc_chat_sessions';
  private readonly MAX_SESSIONS = 20;
  private destroy$ = new Subject<void>();

  quickActions: QuickAction[] = [
    {
      title: 'Draft Presentation',
      description: 'AI-powered slide outline generation with PwC best practices',
      icon: 'draft',
      action: 'draft_ppt'
    },
    {
      title: 'Improve Formatting',
      description: 'Fix spelling, grammar, alignment, and color branding',
      icon: 'improve',
      action: 'improve_ppt'
    },
    {
      title: 'Sanitize Document',
      description: 'Remove client data with tier-based workflow',
      icon: 'sanitize',
      action: 'sanitize_ppt'
    },
    {
      title: 'Validate Best Practices',
      description: 'Check against PwC consulting standards',
      icon: 'validate',
      action: 'validate_ppt'
    }
  ];

  constructor(
    private chatService: ChatService,
    private tlChatBridge: TlChatBridgeService,
    private tlFlowService: TlFlowService,
    private ddcFlowService: DdcFlowService,
    public editWorkflowService: ChatEditWorkflowService
  ) {
    console.log('[ChatComponent] Constructor called');
    console.log('[ChatComponent] TlChatBridge service:', this.tlChatBridge);
  }

  ngOnInit(): void {
    console.log('[ChatComponent] ngOnInit called - v1.1');
    console.log('[ChatComponent] EditWorkflowService injected:', this.editWorkflowService);
    this.loadSessions();
    this.initializeChat();
    this.subscribeToThoughtLeadership();
    this.subscribeToEditWorkflow();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private subscribeToThoughtLeadership(): void {
    console.log('[ChatComponent] Subscribing to Thought Leadership messages');
    console.log('[ChatComponent] message$ observable:', this.tlChatBridge.message$);
    
    this.tlChatBridge.message$
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (message) => {
          console.log('[ChatComponent] Received TL message:', message);
          console.log('[ChatComponent] Current messages count before push:', this.messages.length);
          this.messages.push(message);
          console.log('[ChatComponent] Current messages count after push:', this.messages.length);
          this.saveCurrentSession();
          setTimeout(() => {
            this.messageList?.triggerScrollToBottom();
          }, 100);
        },
        error: (err) => {
          console.error('[ChatComponent] Error in TL subscription:', err);
        },
        complete: () => {
          console.log('[ChatComponent] TL subscription completed');
        }
      });
    
    console.log('[ChatComponent] Subscription setup complete');
  }

  private subscribeToEditWorkflow(): void {
    console.log('[ChatComponent] Subscribing to Edit Workflow messages');
    
    this.editWorkflowService.message$
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (workflowMessage) => {
          console.log('[ChatComponent] Received Edit Workflow message:', workflowMessage);
          this.messages.push(workflowMessage.message);
          this.saveCurrentSession();
          setTimeout(() => {
            this.messageList?.triggerScrollToBottom();
          }, 100);
        },
        error: (err) => {
          console.error('[ChatComponent] Error in Edit Workflow subscription:', err);
        }
      });
    
    console.log('[ChatComponent] Edit Workflow subscription setup complete');
  }

  initializeChat(): void {
    if (this.messages.length === 0) {
      this.messages.push({
        role: 'assistant',
        content: 'Hello! I\'m your MCX AI assistant. How can I help you today?',
        timestamp: new Date()
      });
    }
  }

  async sendMessage(): Promise<void> {
    if ((!this.userInput.trim() && !this.uploadedFile) || this.isLoading) {
      return;
    }

    const userMessage: Message = {
      role: 'user',
      content: this.userInput.trim(),
      timestamp: new Date()
    };

    this.messages.push(userMessage);
    const input = this.userInput.trim();
    this.userInput = '';
    const fileToUpload = this.uploadedFile;
    
    this.messageList?.triggerScrollToBottom();

    const workflowActive = this.editWorkflowService.isActive;

    if (workflowActive) {
      const handled = await this.editWorkflowService.handleChatInput(input, fileToUpload || undefined);
      if (handled) {
        this.uploadedFile = null;
        return;
      }
    }

    console.log('[ChatComponent] Checking for edit intent. Input:', input);
    const hasEditIntent = !workflowActive && this.editWorkflowService.detectEditIntent(input);
    console.log('[ChatComponent] Edit intent detected:', hasEditIntent);
    
    if (hasEditIntent) {
      console.log('[ChatComponent] Starting Edit Content workflow');
      this.editWorkflowService.beginWorkflow();
      const handled = await this.editWorkflowService.handleChatInput(input, fileToUpload || undefined);
      this.uploadedFile = null;
      if (handled) {
        return;
      }
      return;
    }
    
    // Default chat flow - clear file only if not used by workflow
    this.uploadedFile = null;

    // Default chat flow
    this.isLoading = true;

    const assistantMessage: Message = {
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isStreaming: true
    };
    this.messages.push(assistantMessage);

    this.chatService.streamChat(this.messages.slice(0, -1)).subscribe({
      next: (chunk: string) => {
        assistantMessage.content += chunk;
        this.messageList?.triggerScrollToBottom();
      },
      error: (error) => {
        console.error('Error sending message:', error);
        assistantMessage.isStreaming = false;
        assistantMessage.content = 'I apologize, but I encountered an error. Please try again.';
        this.isLoading = false;
      },
      complete: () => {
        assistantMessage.isStreaming = false;
        this.saveCurrentSession();
        this.isLoading = false;
      }
    });
  }

  onFileSelected(file: File): void {
    this.uploadedFile = file;
  }

  onFileRemoved(): void {
    this.uploadedFile = null;
  }

  async onEditorsSubmitted(selectedIds: string[]): Promise<void> {
    await this.editWorkflowService.handleEditorSelection(selectedIds);
  }

  onQuickActionClick(action: string): void {
    console.log('Quick action clicked:', action);
    // Handle quick action - can expand to show forms
  }

  onQuickStart(): void {
    // Initialize quick start flow
    this.userInput = 'I need help creating a presentation';
  }

  onGuidedJourney(): void {
    console.log('[ChatComponent] TL Guided journey initiated');
    this.currentJourney = 'thought-leadership';
    this.currentWorkflows = TL_WORKFLOWS;
    this.showGuidedDialog = true;
  }

  onDdcGuidedJourney(): void {
    console.log('[ChatComponent] DDC Guided journey initiated');
    this.currentJourney = 'ddc';
    this.currentWorkflows = DDC_WORKFLOWS;
    this.showGuidedDialog = true;
  }

  closeGuidedDialog(): void {
    this.showGuidedDialog = false;
    this.currentJourney = null;
    this.currentWorkflows = [];
  }

  onWorkflowSelected(workflowId: string): void {
    console.log(`[ChatComponent] Workflow selected: ${workflowId}, Journey: ${this.currentJourney}`);
    
    if (this.currentJourney === 'thought-leadership') {
      this.tlFlowService.openFlow(workflowId as any);
    } else if (this.currentJourney === 'ddc') {
      this.ddcFlowService.openFlow(workflowId as any);
    }
    
    this.closeGuidedDialog();
  }

  // Legacy method for backwards compatibility
  onTLActionCardClick(flowType: string): void {
    this.closeGuidedDialog();
    this.tlFlowService.openFlow(flowType as 'draft-content' | 'conduct-research' | 'edit-content' | 'refine-content' | 'format-translator' | 'generate-podcast');
  }

  // Chat History Methods
  loadSessions(): void {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        this.savedSessions = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Error loading sessions:', error);
      this.savedSessions = [];
    }
  }

  saveCurrentSession(): void {
    if (this.messages.length <= 1) return;

    const session: ChatSession = {
      id: this.currentSessionId || this.generateSessionId(),
      title: this.generateSessionTitle(),
      messages: [...this.messages],
      timestamp: new Date(),
      lastModified: new Date()
    };

    this.currentSessionId = session.id;

    const existingIndex = this.savedSessions.findIndex(s => s.id === session.id);
    if (existingIndex >= 0) {
      this.savedSessions[existingIndex] = session;
    } else {
      this.savedSessions.unshift(session);
      if (this.savedSessions.length > this.MAX_SESSIONS) {
        this.savedSessions = this.savedSessions.slice(0, this.MAX_SESSIONS);
      }
    }

    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.savedSessions));
    } catch (error) {
      console.error('Error saving session:', error);
    }
  }

  loadSession(sessionId: string): void {
    const session = this.savedSessions.find(s => s.id === sessionId);
    if (session) {
      this.messages = [...session.messages];
      this.currentSessionId = session.id;
      this.showHistoryPanel = false;
    }
  }

  deleteSession(sessionId: string): void {
    this.savedSessions = this.savedSessions.filter(s => s.id !== sessionId);
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.savedSessions));
    } catch (error) {
      console.error('Error deleting session:', error);
    }

    if (this.currentSessionId === sessionId) {
      this.currentSessionId = null;
      this.initializeChat();
    }
  }

  toggleHistoryPanel(): void {
    this.showHistoryPanel = !this.showHistoryPanel;
  }

  private generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateSessionTitle(): string {
    const userMessages = this.messages.filter(m => m.role === 'user');
    if (userMessages.length > 0) {
      const firstMessage = userMessages[0].content;
      return firstMessage.substring(0, 50) + (firstMessage.length > 50 ? '...' : '');
    }
    return 'New Chat';
  }

  get showWelcome(): boolean {
    return this.messages.length <= 1;
  }
}
