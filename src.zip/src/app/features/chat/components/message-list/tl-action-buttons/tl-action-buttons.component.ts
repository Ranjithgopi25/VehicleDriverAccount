import { Component, Input, HostListener, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ThoughtLeadershipMetadata } from '../../../../../core/models';
import { CanvasStateService } from '../../../../../core/services/canvas-state.service';
import { TlChatBridgeService } from '../../../../../core/services/tl-chat-bridge.service';

@Component({
  selector: 'app-tl-action-buttons',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tl-action-buttons.component.html',
  styleUrls: ['./tl-action-buttons.component.scss']
})
export class TlActionButtonsComponent {
  @Input() metadata!: ThoughtLeadershipMetadata;
  @Input() messageId?: string;
  @ViewChild('exportButton') exportButton?: ElementRef<HTMLButtonElement>;
  
  isConvertingToPodcast = false;
  showExportDropdown = false;

  constructor(
    private canvasStateService: CanvasStateService,
    private http: HttpClient,
    private tlChatBridge: TlChatBridgeService
  ) {}

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    const dropdown = target.closest('.dropdown-wrapper');
    
    if (!dropdown && this.showExportDropdown) {
      this.showExportDropdown = false;
    }
  }

  toggleExportDropdown(event: Event): void {
    event.stopPropagation();
    this.showExportDropdown = !this.showExportDropdown;
  }

  handleDropdownKeydown(event: KeyboardEvent): void {
    // Handle Enter or Space to toggle dropdown
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      event.stopPropagation();
      this.showExportDropdown = !this.showExportDropdown;
    }
    // Handle Escape to close dropdown
    else if (event.key === 'Escape' && this.showExportDropdown) {
      event.preventDefault();
      event.stopPropagation();
      this.showExportDropdown = false;
    }
  }

  handleMenuItemKeydown(event: KeyboardEvent): void {
    // Handle Escape to close dropdown and return focus to toggle button
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      this.showExportDropdown = false;
      this.exportButton?.nativeElement.focus();
    }
  }

  downloadWord(): void {
    this.showExportDropdown = false;
    this.exportDocument('/api/export/word', 'docx', 'docx');
    // Return focus to export button for accessibility
    setTimeout(() => this.exportButton?.nativeElement.focus(), 100);
  }

  downloadPDF(): void {
    this.showExportDropdown = false;
    this.exportDocument('/api/export/pdf', 'pdf', 'pdf');
    // Return focus to export button for accessibility
    setTimeout(() => this.exportButton?.nativeElement.focus(), 100);
  }

  downloadText(): void {
    this.showExportDropdown = false;
    this.downloadFile('txt', 'text/plain');
    // Return focus to export button for accessibility
    setTimeout(() => this.exportButton?.nativeElement.focus(), 100);
  }

  downloadPodcast(): void {
    if (this.metadata.podcastAudioUrl && this.metadata.podcastFilename) {
      const link = document.createElement('a');
      link.href = this.metadata.podcastAudioUrl;
      link.download = this.metadata.podcastFilename;
      link.click();
    }
  }

  openInCanvas(): void {
    const contentType = this.metadata.contentType === 'white_paper' ? 'white_paper' : 
                       this.metadata.contentType === 'executive_brief' ? 'executive_brief' : 
                       this.metadata.contentType as 'article' | 'blog';

    this.canvasStateService.loadFromContent(
      this.metadata.fullContent,
      this.metadata.topic,
      contentType,
      this.messageId
    );
  }

  copyToClipboard(): void {
    navigator.clipboard.writeText(this.metadata.fullContent);
  }

  private exportDocument(endpoint: string, extension: string, format: string): void {
    this.http.post(endpoint, {
      content: this.metadata.fullContent,
      title: this.metadata.topic || 'Generated Document',
      format: format
    }, {
      responseType: 'blob',
      observe: 'response'
    }).subscribe({
      next: (response) => {
        const blob = response.body;
        if (blob) {
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          
          // Extract filename from Content-Disposition header or use default
          const contentDisposition = response.headers.get('Content-Disposition');
          let filename = `${this.sanitizeFilename(this.metadata.topic)}.${extension}`;
          if (contentDisposition) {
            const matches = /filename=([^;]+)/.exec(contentDisposition);
            if (matches && matches[1]) {
              filename = matches[1].trim();
            }
          }
          
          link.download = filename;
          link.click();
          window.URL.revokeObjectURL(url);
        }
      },
      error: (err) => {
        console.error(`Error downloading ${extension.toUpperCase()}:`, err);
        alert(`Failed to download ${extension.toUpperCase()} file. Please try again.`);
      }
    });
  }

  private downloadFile(extension: string, mimeType: string): void {
    const blob = new Blob([this.metadata.fullContent], { type: mimeType });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${this.sanitizeFilename(this.metadata.topic)}.${extension}`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  private sanitizeFilename(filename: string): string {
    return filename.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  }

  get isPodcast(): boolean {
    const result = this.metadata.contentType === 'podcast' && !!this.metadata.podcastAudioUrl;
    console.log('[TL Action Buttons] isPodcast check:', {
      contentType: this.metadata.contentType,
      hasPodcastUrl: !!this.metadata.podcastAudioUrl,
      podcastUrl: this.metadata.podcastAudioUrl?.substring(0, 50),
      result: result
    });
    return result;
  }
  
  convertToPodcast(): void {
    if (this.isConvertingToPodcast) return;
    
    this.isConvertingToPodcast = true;
    
    // Prepare the podcast generation request
    const formData = new FormData();
    formData.append('content_text', this.metadata.fullContent);
    formData.append('podcast_style', 'dialogue'); // Default to dialogue style
    
    let scriptContent = '';
    let audioBase64 = '';
    let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
    
    // Use fetch for SSE streaming
    fetch('/api/generate-podcast', {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      
      const readStream = (): any => {
        return reader?.read().then(({ done, value }) => {
          if (done) {
            this.isConvertingToPodcast = false;
            
            console.log('[Podcast Debug] Stream complete');
            console.log('[Podcast Debug] audioBase64 length:', audioBase64?.length || 0);
            console.log('[Podcast Debug] scriptContent length:', scriptContent?.length || 0);
            
            // Send podcast to chat with metadata
            if (audioBase64 && scriptContent) {
              console.log('[Podcast Debug] Converting base64 to blob...');
              const audioBlob = this.base64ToBlob(audioBase64, 'audio/mpeg');
              console.log('[Podcast Debug] Blob size:', audioBlob.size, 'bytes');
              
              const audioUrl = URL.createObjectURL(audioBlob);
              console.log('[Podcast Debug] Audio URL created:', audioUrl);
              
              // Create metadata for the podcast message
              const podcastMetadata: ThoughtLeadershipMetadata = {
                contentType: 'podcast',
                topic: `${this.metadata.topic} (Podcast)`,
                fullContent: scriptContent,
                showActions: true,
                podcastAudioUrl: audioUrl,
                podcastFilename: `${this.sanitizeFilename(this.metadata.topic)}_podcast.mp3`
              };
              
              console.log('[Podcast Debug] Metadata:', podcastMetadata);
              
              // Send to chat via bridge
              const podcastMessage = `📻 **Podcast Generated Successfully!**\n\n**Script:**\n\n${scriptContent}\n\n🎧 **Audio Ready!** Listen below or download the MP3 file.`;
              this.tlChatBridge.sendToChat(podcastMessage, podcastMetadata);
              
              console.log('[Podcast Debug] Sent to chat via bridge');
              alert('Podcast generated and added to chat!');
            } else {
              console.error('[Podcast Debug] Missing data - audioBase64:', !!audioBase64, 'scriptContent:', !!scriptContent);
            }
            return;
          }
          
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';
          
          lines.forEach(line => {
            if (line.startsWith('data: ')) {
              const data = line.slice(6).trim();
              if (data) {
                try {
                  const parsed = JSON.parse(data);
                  console.log('[Podcast Debug] SSE event type:', parsed.type);
                  
                  if (parsed.type === 'script') {
                    scriptContent = parsed.content;
                    console.log('[Podcast Debug] Script received, length:', scriptContent.length);
                  } else if (parsed.type === 'complete') {
                    audioBase64 = parsed.audio;
                    console.log('[Podcast Debug] Audio received, base64 length:', audioBase64?.length || 0);
                  } else if (parsed.type === 'error') {
                    console.error('Podcast generation error:', parsed.message);
                    alert(`Error generating podcast: ${parsed.message}`);
                    
                    // Abort the reader and reset state immediately
                    reader?.cancel();
                    this.isConvertingToPodcast = false;
                    throw new Error(parsed.message);
                  } else if (parsed.type === 'progress') {
                    console.log('[Podcast Debug] Progress:', parsed.message);
                  }
                } catch (e) {
                  console.error('Error parsing SSE data:', e);
                }
              }
            }
          });
          
          return readStream();
        }).catch((error) => {
          // Handle stream reading errors
          this.isConvertingToPodcast = false;
          reader?.cancel();
          throw error;
        });
      };
      
      return readStream();
    })
    .catch(error => {
      console.error('Error converting to podcast:', error);
      alert(`Failed to convert content to podcast: ${error.message || 'Unknown error'}`);
      this.isConvertingToPodcast = false;
      reader?.cancel();
    });
  }
  
  private base64ToBlob(base64: string, contentType: string): Blob {
    const byteCharacters = atob(base64);
    const byteArrays = [];
    
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512);
      const byteNumbers = new Array(slice.length);
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    
    return new Blob(byteArrays, { type: contentType });
  }
}
