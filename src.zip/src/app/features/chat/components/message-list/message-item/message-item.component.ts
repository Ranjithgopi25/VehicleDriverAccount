import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Message, EditorOption } from '../../../../../core/models';
import { Nl2brPipe, SourceCitationPipe } from '../../../../../core/pipes';
import { TlActionButtonsComponent } from '../tl-action-buttons/tl-action-buttons.component';
import { EditorSelectionComponent } from '../../editor-selection/editor-selection.component';

@Component({
  selector: 'app-message-item',
  standalone: true,
  imports: [CommonModule, Nl2brPipe, SourceCitationPipe, TlActionButtonsComponent, EditorSelectionComponent],
  templateUrl: './message-item.component.html',
  styleUrls: ['./message-item.component.scss']
})
export class MessageItemComponent {
  @Input() message!: Message;
  @Output() editorsSubmitted = new EventEmitter<string[]>();

  onEditorsSubmitted(selectedIds: string[]): void {
    this.editorsSubmitted.emit(selectedIds);
  }

  onSelectionChanged(editors: EditorOption[]): void {
    if (this.message.editWorkflow?.editorOptions) {
      this.message.editWorkflow.editorOptions = editors;
    }
  }

  triggerDownload(url: string, filename: string): void {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  openPreview(url: string): void {
    window.open(url, '_blank');
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}
