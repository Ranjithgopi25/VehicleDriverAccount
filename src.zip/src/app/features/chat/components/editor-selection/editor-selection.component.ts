import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditorOption } from '../../../../core/models';

@Component({
  selector: 'app-editor-selection',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './editor-selection.component.html',
  styleUrl: './editor-selection.component.scss'
})
export class EditorSelectionComponent {
  @Input() editors: EditorOption[] = [];
  @Output() selectionChanged = new EventEmitter<EditorOption[]>();
  @Output() submitted = new EventEmitter<string[]>();

  toggleEditor(editor: EditorOption): void {
    const updatedEditors = this.editors.map(e => {
      if (e.id === editor.id) {
        return { ...e, selected: !e.selected };
      }
      return e;
    });
    
    this.editors = updatedEditors;
    this.selectionChanged.emit(updatedEditors);
  }

  isSelected(editorId: string): boolean {
    return this.editors.find(e => e.id === editorId)?.selected || false;
  }

  submitSelection(): void {
    const selectedIds = this.editors.filter(e => e.selected).map(e => e.id);
    this.submitted.emit(selectedIds);
  }

  get canSubmit(): boolean {
    return this.editors.some(e => e.selected);
  }

  get selectedCount(): number {
    return this.editors.filter(e => e.selected).length;
  }
}
