import { Component, EventEmitter, Output, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() featureName: string = 'MCX AI';
  @Input() showSearch: boolean = true;
  @Output() searchChange = new EventEmitter<string>();
  @Output() menuToggle = new EventEmitter<void>();
  @Output() themeToggle = new EventEmitter<void>();
  
  searchQuery: string = '';

  onSearchChange(): void {
    this.searchChange.emit(this.searchQuery);
  }

  onMenuClick(): void {
    this.menuToggle.emit();
  }

  onThemeClick(): void {
    this.themeToggle.emit();
  }
}
