export interface Source {
  number: number;
  url: string;
  title: string;
}

export interface EditorOption {
  id: string;
  name: string;
  icon: string;
  description: string;
  selected: boolean;
}

export interface EditWorkflowMetadata {
  step: 'awaiting_editors' | 'awaiting_content' | 'processing';
  showEditorSelection?: boolean;
  editorOptions?: EditorOption[];
  showCancelButton?: boolean;
}

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: Date;
  downloadUrl?: string;
  downloadFilename?: string;
  previewUrl?: string;
  actionInProgress?: string;
  isStreaming?: boolean;
  sources?: Source[];  // For research citations
  thoughtLeadership?: ThoughtLeadershipMetadata;  // For TL content with actions
  editWorkflow?: EditWorkflowMetadata;  // For Edit Content workflow
}

export interface ThoughtLeadershipMetadata {
  contentType: 'article' | 'blog' | 'white_paper' | 'executive_brief' | 'podcast';
  topic: string;
  fullContent: string;  // Store the complete content for downloads and Canvas
  showActions: boolean;  // Whether to show action buttons
  podcastAudioUrl?: string;  // For podcast playback
  podcastFilename?: string;  // For podcast download
}

export interface ChatRequest {
  messages: Message[];
  stream: boolean;
}

export interface DraftRequest {
  topic: string;
  objective: string;
  audience: string;
  additional_context?: string;
}

export interface ThoughtLeadershipRequest {
  operation: string;
  topic?: string;
  perspective?: string;
  target_audience?: string;
  document_text?: string;
  target_format?: string;
  additional_context?: string;
  reference_urls?: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  timestamp: Date;
  lastModified: Date;
}

export interface ResearchRequest {
  query: string;
  focus_areas?: string[];
  additional_context?: string;
}

export interface ArticleRequest {
  topic: string;
  content_type: string;
  desired_length: number;
  tone: string;
  outline_text?: string;
  additional_context?: string;
}

export interface BestPracticesRequest {
  categories?: string[];
}

export interface PodcastRequest {
  customization?: string;
}
