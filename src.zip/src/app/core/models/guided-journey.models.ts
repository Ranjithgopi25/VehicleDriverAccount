export type JourneyType = 'thought-leadership' | 'ddc';

export interface WorkflowCard {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export interface GuidedJourneyConfig {
  type: JourneyType;
  title: string;
  workflows: WorkflowCard[];
}

export const TL_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'draft-content',
    icon: '✍️',
    title: 'Draft Content',
    description: 'Create articles, blogs, white papers, and podcasts'
  },
  {
    id: 'conduct-research',
    icon: '🔍',
    title: 'Conduct Research',
    description: 'Synthesize insights from multiple documents'
  },
  {
    id: 'edit-content',
    icon: '✏️',
    title: 'Edit Content',
    description: 'Align with PwC brand and style'
  },
  {
    id: 'refine-content',
    icon: '💎',
    title: 'Refine Content',
    description: 'Expand, compress, or adjust tone'
  },
  {
    id: 'format-translator',
    icon: '🔄',
    title: 'Format Translator',
    description: 'Convert between content formats'
  },
  {
    id: 'generate-podcast',
    icon: '🎙️',
    title: 'Generate Podcast',
    description: 'Create audio content with AI voices'
  }
];

export const DDC_WORKFLOWS: WorkflowCard[] = [
  {
    id: 'brand-format',
    icon: '🎨',
    title: 'Branding & Formatting',
    description: 'Apply PwC brand guidelines and professional polish'
  },
  {
    id: 'professional-polish',
    icon: '✨',
    title: 'Professional Polish',
    description: 'Enhance visuals and language quality'
  },
  {
    id: 'sanitization',
    icon: '🔒',
    title: 'Sanitization',
    description: 'Remove client-identifying information'
  },
  {
    id: 'client-customization',
    icon: '🎯',
    title: 'Client Customization',
    description: 'Update decks for new clients'
  },
  {
    id: 'rfp-response',
    icon: '📋',
    title: 'RFP Response',
    description: 'Customize presentations for RFPs'
  },
  {
    id: 'ddc-format-translator',
    icon: '🔄',
    title: 'Format Translator',
    description: 'Convert PPTX to case studies or podcasts'
  },
  {
    id: 'slide-creation',
    icon: '➕',
    title: 'New Slide Creation',
    description: 'Generate slides from images or content'
  }
];
