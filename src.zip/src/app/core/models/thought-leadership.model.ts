export interface ThoughtLeadershipData {
  topic: string;
  perspective: string;
  target_audience: string;
  document_text: string;
  target_format: string;
  additional_context: string;
  reference_document: string;
  reference_link: string;
}

export interface ResearchData {
  query: string;
  focus_areas: string[];
  additional_context: string;
  files?: File[];
  links?: string[];
}

export interface PodcastData {
  files: File[];
  content_text: string;
  customization: string;
  podcast_style: 'dialogue' | 'monologue';
}

export interface ArticleDraftData {
  topic: string;
  content_type: 'Article' | 'Case Study' | 'Executive Brief' | 'Blog';
  desired_length: number;
  tone: 'Professional' | 'Conversational' | 'Technical';
  outline_text: string;
  additional_context: string;
  outline_file?: File;
  supporting_docs?: File[];
}
