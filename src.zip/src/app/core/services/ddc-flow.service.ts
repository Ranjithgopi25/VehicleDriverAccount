import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export type DDCFlowType = 
  | 'brand-format'
  | 'professional-polish'
  | 'sanitization'
  | 'client-customization'
  | 'rfp-response'
  | 'ddc-format-translator'
  | 'slide-creation'
  | null;

@Injectable({
  providedIn: 'root'
})
export class DdcFlowService {
  private activeFlowSubject = new BehaviorSubject<DDCFlowType>(null);
  public activeFlow$: Observable<DDCFlowType> = this.activeFlowSubject.asObservable();

  openFlow(flowType: DDCFlowType): void {
    this.activeFlowSubject.next(flowType);
  }

  closeFlow(): void {
    this.activeFlowSubject.next(null);
  }

  get currentFlow(): DDCFlowType {
    return this.activeFlowSubject.value;
  }
}
