import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';
import { Message, ThoughtLeadershipMetadata } from '../models';

export interface ThoughtLeadershipMessage {
  message: Message;
  metadata: ThoughtLeadershipMetadata;
}

@Injectable({
  providedIn: 'root'
})
export class TlChatBridgeService {
  // Use ReplaySubject to buffer the last message in case of timing issues
  private messageSubject = new ReplaySubject<Message>(1);
  
  // Observable that components can subscribe to
  public message$ = this.messageSubject.asObservable();

  constructor() {
    console.log('[TlChatBridge] Service instance created');
  }

  /**
   * Send Thought Leadership content to the chat window
   * @param content - The generated content (markdown/text)
   * @param metadata - Metadata about the content type, topic, etc.
   */
  sendToChat(content: string, metadata: ThoughtLeadershipMetadata): void {
    console.log('[TlChatBridge] sendToChat() called');
    console.log('[TlChatBridge] Content:', content.substring(0, 100) + '...');
    console.log('[TlChatBridge] Metadata:', metadata);
    
    const message: Message = {
      role: 'assistant',
      content: content,
      timestamp: new Date(),
      thoughtLeadership: metadata
    };

    console.log('[TlChatBridge] Emitting message via messageSubject');
    this.messageSubject.next(message);
    console.log('[TlChatBridge] Message emitted');
  }
}
