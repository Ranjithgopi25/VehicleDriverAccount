import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Message, ChatRequest, DraftRequest, ThoughtLeadershipRequest, ResearchRequest, ArticleRequest, BestPracticesRequest, PodcastRequest, UpdateSectionRequest } from '../models';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  sendMessage(messages: Message[]): Observable<any> {
    const request: ChatRequest = {
      messages: messages,
      stream: false
    };
    
    return this.http.post(`${this.apiUrl}/api/chat`, request);
  }

  createDraft(draftRequest: DraftRequest): Observable<any> {
    return this.http.post(`${this.apiUrl}/api/draft`, draftRequest);
  }

  streamChat(messages: Message[]): Observable<string> {
    return new Observable(observer => {
      const request: ChatRequest = {
        messages: messages,
        stream: true
      };

      fetch(`${this.apiUrl}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamDraft(draftRequest: DraftRequest): Observable<string> {
    return new Observable(observer => {
      fetch(`${this.apiUrl}/api/draft`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(draftRequest)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamThoughtLeadership(tlRequest: ThoughtLeadershipRequest): Observable<string> {
    return new Observable(observer => {
      fetch(`${this.apiUrl}/api/thought-leadership`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(tlRequest)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  improvePPT(originalFile: File, referenceFile: File | null): Observable<Blob> {
    return new Observable(observer => {
      const formData = new FormData();
      formData.append('original_ppt', originalFile);
      if (referenceFile) {
        formData.append('reference_ppt', referenceFile);
      }

      fetch(`${this.apiUrl}/api/ppt/improve`, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.blob();
      })
      .then(blob => {
        observer.next(blob);
        observer.complete();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamSanitizationConversation(
    messages: Message[], 
    uploadedFileName?: string,
    clientIdentity?: string,
    pageRange?: string,
    tier1Services?: string[],
    tier2Services?: string[]
  ): Observable<string> {
    return new Observable(observer => {
      const request = {
        messages: messages,
        uploaded_file_name: uploadedFileName,
        client_identity: clientIdentity,
        page_range: pageRange,
        tier1_services: tier1Services,
        tier2_services: tier2Services,
        stream: true
      };

      fetch(`${this.apiUrl}/api/ppt/sanitize/conversation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  sanitizePPT(file: File, clientName: string, products: string, options?: any): Observable<{blob: Blob, stats: any}> {
    return new Observable(observer => {
      const formData = new FormData();
      formData.append('original_ppt', file);
      if (clientName) {
        formData.append('client_name', clientName);
      }
      if (products) {
        formData.append('client_products', products);
      }
      if (options) {
        // Convert camelCase to snake_case for backend
        const backendOptions = {
          numeric_data: options.numericData,
          personal_info: options.personalInfo,
          financial_data: options.financialData,
          locations: options.locations,
          identifiers: options.identifiers,
          names: options.names,
          logos: options.logos,
          metadata: options.metadata,
          llm_detection: options.llmDetection,
          hyperlinks: options.hyperlinks,
          embedded_objects: options.embeddedObjects
        };
        formData.append('sanitization_options', JSON.stringify(backendOptions));
      }

      fetch(`${this.apiUrl}/api/ppt/sanitize`, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const statsHeader = response.headers.get('X-Sanitization-Stats');
        let stats = null;
        if (statsHeader) {
          try {
            stats = JSON.parse(statsHeader);
          } catch (e) {
            console.warn('Could not parse sanitization stats');
          }
        }
        return response.blob().then(blob => ({blob, stats}));
      })
      .then(result => {
        observer.next(result);
        observer.complete();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamDdcWorkflow(workflow: 'brand-format' | 'professional-polish' | 'sanitization' | 'client-customization' | 'rfp-response' | 'ddc-format-translator' | 'slide-creation', formData: FormData): Observable<string> {
    return this.streamFormData(`${this.apiUrl}/api/ddc/${workflow}`, formData);
  }

  streamDdcBrandFormat(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('brand-format', formData);
  }

  streamDdcProfessionalPolish(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('professional-polish', formData);
  }

  streamDdcSanitization(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('sanitization', formData);
  }

  streamDdcClientCustomization(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('client-customization', formData);
  }

  streamDdcRfpResponse(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('rfp-response', formData);
  }

  streamDdcFormatTranslator(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('ddc-format-translator', formData);
  }

  streamDdcSlideCreation(formData: FormData): Observable<string> {
    return this.streamDdcWorkflow('slide-creation', formData);
  }

  private streamFormData(endpoint: string, formData: FormData): Observable<string> {
    return new Observable(observer => {
      fetch(endpoint, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  exportDocument(content: string, title: string, format: string): Observable<Blob> {
    return new Observable(observer => {
      const endpoint = format === 'pdf' ? '/api/export/pdf' : '/api/export/word';
      
      fetch(`${this.apiUrl}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content, title, format })
      })
      .then(response => {
        if (!response.ok) {
          throw new Error(`Export failed: ${response.statusText}`);
        }
        return response.blob();
      })
      .then(blob => {
        observer.next(blob);
        observer.complete();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamResearch(researchRequest: any): Observable<string> {
    return new Observable(observer => {
      fetch(`${this.apiUrl}/api/research`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(researchRequest)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  draftArticle(articleData: any, outlineFile?: File, supportingDocs?: File[]): Observable<string> {
    return new Observable(observer => {
      const formData = new FormData();
      formData.append('topic', articleData.topic);
      formData.append('content_type', articleData.content_type);
      formData.append('desired_length', articleData.desired_length.toString());
      formData.append('tone', articleData.tone);
      
      if (articleData.outline_text) {
        formData.append('outline_text', articleData.outline_text);
      }
      if (articleData.additional_context) {
        formData.append('additional_context', articleData.additional_context);
      }
      if (outlineFile) {
        formData.append('outline_file', outlineFile);
      }
      if (supportingDocs && supportingDocs.length > 0) {
        supportingDocs.forEach(doc => {
          formData.append('supporting_docs', doc);
        });
      }

      fetch(`${this.apiUrl}/api/draft-article`, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamBestPractices(file: File, categories?: string[]): Observable<string> {
    return new Observable(observer => {
      const formData = new FormData();
      formData.append('file', file);
      if (categories && categories.length > 0) {
        formData.append('categories', categories.join(','));
      }

      fetch(`${this.apiUrl}/api/validate-best-practices`, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  generatePodcast(files: File[] | null, contentText: string | null, customization: string | null, podcastStyle: string = 'dialogue'): Observable<any> {
    return new Observable(observer => {
      const formData = new FormData();
      
      if (files && files.length > 0) {
        files.forEach(file => {
          formData.append('files', file);
        });
      }
      
      if (contentText) {
        formData.append('content_text', contentText);
      }
      
      if (customization) {
        formData.append('customization', customization);
      }
      
      formData.append('podcast_style', podcastStyle);

      fetch(`${this.apiUrl}/api/generate-podcast`, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    observer.next(parsed);
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  streamResearchWithMaterials(
    files: File[] | null,
    links: string[] | null,
    query: string,
    focusAreas: string[],
    additionalContext: string | null
  ): Observable<any> {
    return new Observable(observer => {
      const formData = new FormData();
      
      if (files && files.length > 0) {
        files.forEach(file => {
          formData.append('files', file);
        });
      }
      
      if (links && links.length > 0) {
        links.forEach(link => {
          formData.append('links', link);
        });
      }
      
      formData.append('query', query);
      
      if (focusAreas && focusAreas.length > 0) {
        formData.append('focus_areas', JSON.stringify(focusAreas));
      }
      
      if (additionalContext) {
        formData.append('additional_context', additionalContext);
      }

      fetch(`${this.apiUrl}/api/research-with-materials`, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    observer.next(parsed);
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  // NEW: Thought Leadership Section Methods (5 Sections)

  streamDraftContent(messages: Message[]): Observable<any> {
    return new Observable(observer => {
      const request = { messages, stream: true };

      fetch(`${this.apiUrl}/api/tl/draft-content`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    observer.next(JSON.parse(data));
                  } catch (e) {
                    console.error('Error parsing SSE data:', e);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => observer.error(error));
    });
  }

  streamConductResearch(messages: Message[], sourceGroups?: string[]): Observable<any> {
    return new Observable(observer => {
      const request: any = { messages, stream: true };
      if (sourceGroups && sourceGroups.length > 0) {
        request.source_groups = sourceGroups;
      }

      fetch(`${this.apiUrl}/api/tl/conduct-research`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    observer.next(JSON.parse(data));
                  } catch (e) {
                    console.error('Error parsing SSE data:', e);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => observer.error(error));
    });
  }

  streamEditContent(messages: Message[], editorTypes?: string[]): Observable<any> {
    return new Observable(observer => {
      const request = { 
        messages, 
        stream: true,
        editor_types: editorTypes || []
      };

      fetch(`${this.apiUrl}/api/tl/edit-content`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    observer.next(JSON.parse(data));
                  } catch (e) {
                    console.error('Error parsing SSE data:', e);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => observer.error(error));
    });
  }

  generateEditContentTitle(content: string): Observable<{ title: string }> {
    return this.http.post<{ title: string }>(
      `${this.apiUrl}/api/tl/edit-content/generate-title`,
      { content }
    );
  }

  streamRefineContent(messages: Message[]): Observable<any> {
    return new Observable(observer => {
      const request = { messages, stream: true };

      fetch(`${this.apiUrl}/api/tl/refine-content`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    observer.next(JSON.parse(data));
                  } catch (e) {
                    console.error('Error parsing SSE data:', e);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => observer.error(error));
    });
  }

  streamFormatTranslator(messages: Message[]): Observable<any> {
    return new Observable(observer => {
      const request = { messages, stream: true };

      fetch(`${this.apiUrl}/api/tl/format-translator`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    observer.next(JSON.parse(data));
                  } catch (e) {
                    console.error('Error parsing SSE data:', e);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => observer.error(error));
    });
  }

  streamSectionUpdate(request: UpdateSectionRequest): Observable<string> {
    return new Observable(observer => {
      fetch(`${this.apiUrl}/api/thought-leadership/update-section`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        function readStream(): any {
          return reader?.read().then(({ done, value }) => {
            if (done) {
              observer.complete();
              return;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            lines.forEach(line => {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim();
                if (data) {
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.content) {
                      observer.next(parsed.content);
                    } else if (parsed.done) {
                      observer.complete();
                    } else if (parsed.error) {
                      observer.error(new Error(parsed.error));
                    }
                  } catch (e) {
                    console.error('Error parsing SSE data:', e, 'Data:', data);
                  }
                }
              }
            });

            return readStream();
          });
        }

        return readStream();
      })
      .catch(error => {
        observer.error(error);
      });
    });
  }

  exportToWord(data: { content: string; title: string }): Observable<Blob> {
    return this.http.post(`${this.apiUrl}/api/export/word`, data, {
      responseType: 'blob'
    });
  }

  exportToPDF(data: { content: string; title: string }): Observable<Blob> {
    return this.http.post(`${this.apiUrl}/api/export/pdf`, data, {
      responseType: 'blob'
    });
  }

  exportToText(data: { content: string; title: string }): Observable<Blob> {
    return this.http.post(`${this.apiUrl}/api/export/text`, data, {
      responseType: 'blob'
    });
  }
}
