import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type ThemeMode = 'light' | 'dark' | 'auto';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private currentTheme = new BehaviorSubject<ThemeMode>('auto');
  public theme$ = this.currentTheme.asObservable();

  constructor() {
    // Load saved theme preference or default to auto
    const savedTheme = localStorage.getItem('theme') as ThemeMode;
    if (savedTheme) {
      this.setTheme(savedTheme);
    } else {
      this.applyTheme('auto');
    }
  }

  setTheme(theme: ThemeMode): void {
    this.currentTheme.next(theme);
    localStorage.setItem('theme', theme);
    this.applyTheme(theme);
  }

  private applyTheme(theme: ThemeMode): void {
    const root = document.documentElement;
    
    if (theme === 'auto') {
      // Check system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    } else {
      root.setAttribute('data-theme', theme);
    }
  }

  getCurrentTheme(): ThemeMode {
    return this.currentTheme.value;
  }
}
