import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export type TLFlowType = 'draft-content' | 'conduct-research' | 'edit-content' | 'refine-content' | 'format-translator' | 'generate-podcast' | null;

@Injectable({
  providedIn: 'root'
})
export class TlFlowService {
  private activeFlowSubject = new BehaviorSubject<TLFlowType>(null);
  public activeFlow$: Observable<TLFlowType> = this.activeFlowSubject.asObservable();

  openFlow(flowType: TLFlowType): void {
    this.activeFlowSubject.next(flowType);
  }

  closeFlow(): void {
    this.activeFlowSubject.next(null);
  }

  get currentFlow(): TLFlowType {
    return this.activeFlowSubject.value;
  }
}
