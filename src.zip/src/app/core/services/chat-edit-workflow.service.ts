import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { Message } from '../models';
import { ChatService } from './chat.service';

export type EditWorkflowStep = 'idle' | 'awaiting_editors' | 'awaiting_content' | 'processing';

export interface EditWorkflowState {
  step: EditWorkflowStep;
  uploadedFile: File | null;
  selectedEditors: string[];
  originalContent: string;
  requestContext: string;
}

export interface EditWorkflowMessage {
  type: 'prompt' | 'result';
  message: Message;
  metadata?: any;
}

export interface EditorOption {
  id: string;
  name: string;
  icon: string;
  description: string;
  selected: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ChatEditWorkflowService {
  private chatService = inject(ChatService);

  private stateSubject = new BehaviorSubject<EditWorkflowState>({
    step: 'idle',
    uploadedFile: null,
    selectedEditors: [],
    originalContent: '',
    requestContext: ''
  });

  public state$: Observable<EditWorkflowState> = this.stateSubject.asObservable();

  private messageSubject = new Subject<EditWorkflowMessage>();
  public message$: Observable<EditWorkflowMessage> = this.messageSubject.asObservable();

  readonly editorOptions: EditorOption[] = [
    { 
      id: 'development', 
      name: 'Development Editor', 
      icon: '🚀', 
      description: 'Reviews and restructures content for alignment and coherence',
      selected: true
    },
    { 
      id: 'content', 
      name: 'Content Editor', 
      icon: '📄', 
      description: "Refines language to align with author's key objectives",
      selected: true
    },
    { 
      id: 'line', 
      name: 'Line Editor', 
      icon: '📝', 
      description: 'Improves sentence flow, readability and style preserving voice',
      selected: true
    },
    { 
      id: 'copy', 
      name: 'Copy Editor', 
      icon: '✏️', 
      description: 'Corrects grammar, punctuation and typos',
      selected: true
    },
    { 
      id: 'brand-alignment', 
      name: 'PwC Brand Alignment Editor', 
      icon: '🎯', 
      description: 'Aligns content writing standards with PwC brand',
      selected: false
    }
  ];

  readonly supportedFileTypes: string[] = ['.docx', '.doc', '.pdf', '.txt', '.md', '.markdown'];

  readonly fileAccept: string = this.supportedFileTypes.join(',');

  get currentState(): EditWorkflowState {
    return this.stateSubject.value;
  }

  get isActive(): boolean {
    return this.currentState.step !== 'idle';
  }

  detectEditIntent(input: string): boolean {
    const editKeywords = [
      'edit content', 
      'edit my content',
      'edit this content',
      'edit the content',
      'edit article', 
      'edit my article',
      'edit this article',
      'edit the article',
      'edit document',
      'edit my document',
      'edit this document',
      'edit the document',
      'edit my writing',
      'edit this writing',
      'help me edit', 
      'i need to edit', 
      'can you edit',
      'review content',
      'review my content',
      'review this content',
      'review the content',
      'review article',
      'review my article',
      'review this article',
      'review the article',
      'review document',
      'review my document',
      'review this document',
      'review the document',
      'review my writing',
      'review this writing',
      'improve content',
      'improve my content',
      'improve this content',
      'improve the content',
      'improve article',
      'improve my article',
      'improve this article',
      'improve the article',
      'improve document',
      'improve my document',
      'improve this document',
      'improve the document',
      'improve my writing',
      'improve this writing'
    ];
    const lowerInput = input.toLowerCase();
    const detected = editKeywords.some(keyword => lowerInput.includes(keyword));
    console.log('[ChatEditWorkflow] detectEditIntent called. Input:', input, 'Detected:', detected);
    return detected;
  }

  beginWorkflow(initialRequest: string = ''): void {
    const sanitizedRequest = initialRequest.trim();
    this.updateState({
      step: 'awaiting_editors',
      uploadedFile: null,
      selectedEditors: [],
      originalContent: '',
      requestContext: sanitizedRequest
    });

    const promptMessage: Message = {
      role: 'assistant',
      content: `I'll help you edit your content! 📝\n\n**Step 1: Choose your editing services**\nUse the editor chips below to pick the passes you want. You can keep the defaults, turn any off, or let me know which sections need special attention.\n\nTell me if you want to skip a persona (“remove the copy edit pass”) or focus the review on specific pages.\n\nOnce your selection looks right, I’ll ask for the document (or pasted text) so we can get started.`,
      timestamp: new Date(),
      editWorkflow: {
        step: 'awaiting_editors',
        showEditorSelection: true,
        editorOptions: this.buildEditorOptionsSnapshot(),
        showCancelButton: true
      }
    };

    this.messageSubject.next({
      type: 'prompt',
      message: promptMessage
    });
  }

  async handleChatInput(input: string, uploadedFile?: File): Promise<boolean> {
    if (!this.isActive) {
      return false;
    }

    const trimmedInput = (input || '').trim();

    if (trimmedInput.length > 0) {
      this.appendRequestContext(trimmedInput);
    }

    const state = this.currentState;

    switch (state.step) {
      case 'awaiting_editors':
        if (trimmedInput.length > 0) {
          const reminderMessage: Message = {
            role: 'assistant',
            content: `Thanks for the details! Please use the editor picker above to choose the editing services you'd like. After selecting them, click **Continue** to move on.`,
            timestamp: new Date(),
            editWorkflow: {
              step: 'awaiting_editors',
              showEditorSelection: true,
              editorOptions: this.buildEditorOptionsSnapshot(),
              showCancelButton: true
            }
          };
          this.messageSubject.next({ type: 'prompt', message: reminderMessage });
        }
        return true;
      case 'awaiting_content':
        if (uploadedFile) {
          await this.handleFileUpload(uploadedFile);
          return true;
        }

        if (trimmedInput.length === 0) {
          const promptMessage: Message = {
            role: 'assistant',
            content: `⚠️ **Please provide your content to continue.**\n\nYou need to provide **either**:\n• Upload a document using the paperclip button (Word, PDF, Text, Markdown)\n• **OR** paste your content directly into the chat\n\nBoth options cannot be empty.`,
            timestamp: new Date(),
            editWorkflow: {
              step: 'awaiting_content',
              showCancelButton: true
            }
          };
          this.messageSubject.next({ type: 'prompt', message: promptMessage });
          return true;
        }

        await this.handleTextSubmission(trimmedInput);
        return true;
      case 'processing':
        if (trimmedInput.length > 0) {
          const processingMessage: Message = {
            role: 'assistant',
            content: `I'm still working on your edits. I'll share the feedback and revised article as soon as it's ready!`,
            timestamp: new Date()
          };
          this.messageSubject.next({ type: 'prompt', message: processingMessage });
        }
        return true;
      default:
        return false;
    }
  }

  async handleFileUpload(file: File): Promise<void> {
    const state = this.currentState;

    if (state.step === 'awaiting_editors') {
      const reminderMessage: Message = {
        role: 'assistant',
        content: `Please select the editing services first. Once you've chosen them, you can upload your document.`,
        timestamp: new Date(),
        editWorkflow: {
          step: 'awaiting_editors',
          showEditorSelection: true,
          editorOptions: this.buildEditorOptionsSnapshot(),
          showCancelButton: true
        }
      };
      this.messageSubject.next({ type: 'prompt', message: reminderMessage });
      return;
    }

    if (state.step !== 'awaiting_content') {
      console.warn('[ChatEditWorkflow] File upload received but workflow is not ready for content submission.');
      return;
    }

    this.updateState({
      ...state,
      uploadedFile: file
    });

    await this.startProcessingWithFile(file);
  }

  private async handleTextSubmission(text: string): Promise<void> {
    const state = this.currentState;
    if (state.step !== 'awaiting_content') {
      console.warn('[ChatEditWorkflow] Text submission received but workflow is not waiting for content.');
      return;
    }

    if (state.selectedEditors.length === 0) {
      const promptMessage: Message = {
        role: 'assistant',
        content: 'Please select the editing services before submitting content.',
        timestamp: new Date(),
        editWorkflow: {
          step: 'awaiting_editors',
          showEditorSelection: true,
          editorOptions: this.buildEditorOptionsSnapshot(),
          showCancelButton: true
        }
      };
      this.messageSubject.next({ type: 'prompt', message: promptMessage });
      this.updateState({
        ...state,
        step: 'awaiting_editors'
      });
      return;
    }

    const selectedNames = this.getEditorNames(state.selectedEditors);

    this.updateState({
      ...state,
      originalContent: text,
      step: 'processing'
    });

    await this.processContent(text, state.selectedEditors, selectedNames, { type: 'text' });
  }

  private async startProcessingWithFile(file: File): Promise<void> {
    const state = this.currentState;

    if (state.selectedEditors.length === 0) {
      const promptMessage: Message = {
        role: 'assistant',
        content: 'Please select the editing services before submitting content.',
        timestamp: new Date(),
        editWorkflow: {
          step: 'awaiting_editors',
          showEditorSelection: true,
          editorOptions: this.buildEditorOptionsSnapshot(),
          showCancelButton: true
        }
      };
      this.messageSubject.next({ type: 'prompt', message: promptMessage });
      this.updateState({
        ...state,
        step: 'awaiting_editors'
      });
      return;
    }

    const selectedNames = this.getEditorNames(state.selectedEditors);

    this.updateState({
      ...state,
      step: 'processing'
    });

    try {
      const contentText = await this.extractFileText(file);
      this.updateState({
        ...this.currentState,
        originalContent: contentText
      });

      await this.processContent(contentText, this.currentState.selectedEditors, selectedNames, { type: 'file', name: file.name });
    } catch (error) {
      console.error('[ChatEditWorkflow] Error processing content:', error);
      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, there was an error processing your document. Please try again.',
        timestamp: new Date()
      };
      this.messageSubject.next({ type: 'result', message: errorMessage });
      this.completeWorkflow();
    }
  }

  async handleEditorSelection(selectedIds: string[]): Promise<void> {
    if (this.currentState.step !== 'awaiting_editors') {
      console.warn('[ChatEditWorkflow] Editor selection received but not in awaiting_editors state');
      return;
    }

    if (selectedIds.length === 0) {
      const warningMessage: Message = {
        role: 'assistant',
        content: 'Please select at least one editing service to continue.',
        timestamp: new Date(),
        editWorkflow: {
          step: 'awaiting_editors',
          showEditorSelection: true,
          editorOptions: this.buildEditorOptionsSnapshot(),
          showCancelButton: true
        }
      };
      this.messageSubject.next({ type: 'prompt', message: warningMessage });
      return;
    }

    this.updateState({
      ...this.currentState,
      selectedEditors: selectedIds,
      step: 'awaiting_content'
    });

    const selectedNames = this.getEditorNames(selectedIds);

    const promptMessage: Message = {
      role: 'assistant',
      content: `Excellent choice! ✨\n\n**Step 2: Provide your content**\n\nPlease provide your content using **one** of these options:\n• **Upload a document** using the paperclip icon (Word, PDF, Text, Markdown)\n• **Paste your content** directly into the chat\n\n⚠️ **Required:** You must provide either a document upload OR paste text to proceed.\n\nOnce I have the content, I'll apply: **${selectedNames}**`,
      timestamp: new Date(),
      editWorkflow: {
        step: 'awaiting_content',
        showCancelButton: true
      }
    };

    this.messageSubject.next({ type: 'prompt', message: promptMessage });
  }

  private async extractFileText(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch('/api/extract-text', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error('Failed to extract text from file');
    }
    
    const data = await response.json();
    return data.text || '';
  }

  private async processContent(
    contentText: string,
    selectedIds: string[],
    selectedNames: string,
    source?: { type: 'file' | 'text'; name?: string }
  ): Promise<void> {
    const wordCount = contentText.split(/\s+/).filter(w => w.length > 0).length;
    const requestContext = this.currentState.requestContext
      ? `\n\nAdditional user instructions:\n${this.currentState.requestContext}`
      : '';
    const sourceContext = source?.type === 'file' && source.name
      ? `\n\nSource file: ${source.name}`
      : '';
    
    const contentMessage = `You are a professional editorial service. Please analyze the following content using these editor types: ${selectedNames}.

IMPORTANT INSTRUCTIONS:
1. Provide your response in TWO clear sections:
   - Section 1: FEEDBACK - Editorial comments, suggestions, and observations
   - Section 2: REVISED ARTICLE - The fully edited version of the content
   
2. For the REVISED ARTICLE section:
   - Apply all edits you recommended in the feedback
   - Maintain approximately the same length (~${wordCount} words)
   - Preserve the core message and structure
   - Make it publication-ready

Format your response exactly like this:
=== FEEDBACK ===
[Your editorial feedback and suggestions here]

=== REVISED ARTICLE ===
[The fully revised and edited content here]

Content to Review:
${contentText}${sourceContext}${requestContext}`;
    
    const messages = [{
      role: 'user' as const,
      content: contentMessage
    }];

    let fullResponse = '';

    this.chatService.streamEditContent(messages, selectedIds).subscribe({
      next: (data: any) => {
        let chunk = '';
        if (typeof data === 'string') {
          chunk = data;
        } else if (data.type === 'content' && data.content) {
          chunk = data.content;
        }
        
        fullResponse += chunk;
      },
      error: (error: any) => {
        console.error('[ChatEditWorkflow] Error during edit streaming:', error);
        const errorMsg: Message = {
          role: 'assistant',
          content: 'Sorry, there was an error editing your content. Please try again.',
          timestamp: new Date()
        };
        this.messageSubject.next({ type: 'result', message: errorMsg });
        this.completeWorkflow();
      },
      complete: () => {
        this.displayResults(fullResponse);
        this.completeWorkflow();
      }
    });
  }

  private displayResults(fullResponse: string): void {
    const feedbackMatch = fullResponse.match(/===\s*FEEDBACK\s*===\s*([\s\S]*?)(?====\s*REVISED ARTICLE\s*===|$)/i);
    const revisedMatch = fullResponse.match(/===\s*REVISED ARTICLE\s*===\s*([\s\S]*?)$/i);
    
    // Display Feedback Section
    if (feedbackMatch && feedbackMatch[1]) {
      const feedbackPlainText = feedbackMatch[1].trim();
      const feedbackMessage: Message = {
        role: 'assistant',
        content: `**📝 Editorial Feedback**\n\n${feedbackPlainText}`,
        timestamp: new Date(),
        thoughtLeadership: {
          contentType: 'article',
          topic: 'Editorial Feedback',
          fullContent: feedbackPlainText,
          showActions: true
        }
      };
      this.messageSubject.next({ type: 'result', message: feedbackMessage });
    }
    
    // Display Revised Article Section
    if (revisedMatch && revisedMatch[1]) {
      const revisedContent = revisedMatch[1].trim();
      const revisedMessage: Message = {
        role: 'assistant',
        content: `**✨ Revised Article**\n\n${revisedContent}`,
        timestamp: new Date(),
        thoughtLeadership: {
          contentType: 'article',
          topic: 'Revised Article',
          fullContent: revisedContent,
          showActions: true
        }
      };
      this.messageSubject.next({ type: 'result', message: revisedMessage });
    }
    
    // If parsing failed, show the full response
    if (!feedbackMatch && !revisedMatch) {
      const fallbackMessage: Message = {
        role: 'assistant',
        content: fullResponse,
        timestamp: new Date(),
        thoughtLeadership: {
          contentType: 'article',
          topic: 'Edited Content',
          fullContent: fullResponse,
          showActions: true
        }
      };
      this.messageSubject.next({ type: 'result', message: fallbackMessage });
    }
  }

  private formatMarkdown(text: string): string {
    let formatted = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*(.+?)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/\n/g, '<br>');
    return formatted;
  }

  cancelWorkflow(): void {
    // Only cancel if workflow is actually active
    if (!this.isActive) {
      return;
    }

    this.updateState({
      step: 'idle',
      uploadedFile: null,
      selectedEditors: ['development', 'content', 'line', 'copy'],
      originalContent: '',
      requestContext: ''
    });

    const cancelMessage: Message = {
      role: 'assistant',
      content: 'Edit workflow cancelled. How else can I help you?',
      timestamp: new Date()
    };

    this.messageSubject.next({
      type: 'prompt',
      message: cancelMessage
    });
  }

  completeWorkflow(): void {
    this.updateState({
      step: 'idle',
      uploadedFile: null,
      selectedEditors: ['development', 'content', 'line', 'copy'],
      originalContent: '',
      requestContext: ''
    });
  }

  async processFromGuidedFlow(file: File, selectedIds: string[]): Promise<void> {
    if (!file) {
      throw new Error('Please upload a document to edit.');
    }

    if (selectedIds.length === 0) {
      throw new Error('Please select at least one editing service.');
    }

    const selectedNames = selectedIds
      .map(id => this.editorOptions.find(e => e.id === id)?.name)
      .filter((name): name is string => !!name);

    let contentText: string;

    try {
      contentText = await this.extractFileText(file);
    } catch (error) {
      console.error('[ChatEditWorkflow] Failed to extract text from guided flow upload:', error);
      throw new Error('Error reading uploaded file. Please try again.');
    }

    this.updateState({
      step: 'processing',
      uploadedFile: file,
      selectedEditors: selectedIds,
      originalContent: contentText,
      requestContext: ''
    });

    const editorsLabel = selectedNames.length > 0
      ? selectedNames.join(', ')
      : 'the selected editing services';

    const startMessage: Message = {
      role: 'assistant',
      content: `📄 **Edit Content workflow started**\n\nReceived **${file.name}** and applying: **${editorsLabel}**.\n\nI'll share editorial feedback and the revised article right here once it's ready.`,
      timestamp: new Date()
    };

    this.messageSubject.next({
      type: 'prompt',
      message: startMessage
    });

    await this.processContent(contentText, selectedIds, editorsLabel, { type: 'file', name: file.name });
  }

  private updateState(newState: EditWorkflowState): void {
    this.stateSubject.next(newState);
  }

  private appendRequestContext(newInstruction: string): void {
    const trimmed = newInstruction.trim();
    if (!trimmed) {
      return;
    }

    const current = this.currentState.requestContext;
    const updatedContext = current ? `${current}\n${trimmed}` : trimmed;

    this.updateState({
      ...this.currentState,
      requestContext: updatedContext
    });
  }

  private getEditorNames(selectedIds: string[]): string {
    return selectedIds
      .map(id => this.editorOptions.find(e => e.id === id)?.name)
      .filter((name): name is string => !!name)
      .join(', ');
  }

  private buildEditorOptionsSnapshot(selectedIds?: string[]): EditorOption[] {
    const activeSelections = selectedIds ?? this.currentState.selectedEditors;
    return this.editorOptions.map(opt => ({
      ...opt,
      selected: activeSelections.includes(opt.id)
    }));
  }
}
