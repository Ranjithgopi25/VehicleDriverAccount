import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-file-upload',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => FileUploadComponent),
      multi: true
    }
  ]
})
export class FileUploadComponent implements ControlValueAccessor {
  @Input() accept: string = '*';
  @Input() required: boolean = false;
  @Input() size: 'small' | 'normal' = 'normal';
  @Input() label: string = 'Upload File';
  @Input() multiple: boolean = false;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() filesSelected = new EventEmitter<File[]>();

  uploadedFile: File | null = null;
  uploadedFiles: File[] = [];
  private onChange: (file: File | File[] | null) => void = () => {};
  private onTouched: () => void = () => {};

  writeValue(value: File | File[] | null): void {
    if (value === null) {
      this.uploadedFile = null;
      this.uploadedFiles = [];
    } else if (Array.isArray(value)) {
      this.uploadedFile = null;
      this.uploadedFiles = value;
    } else {
      this.uploadedFiles = [];
      this.uploadedFile = value;
    }
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  onFileSelect(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.onTouched();
    
    if (input.files && input.files.length > 0) {
      if (this.multiple) {
        this.uploadedFiles = Array.from(input.files);
        this.onChange(this.uploadedFiles);
        this.filesSelected.emit(this.uploadedFiles);
      } else {
        this.uploadedFile = input.files[0];
        this.onChange(this.uploadedFile);
        this.fileSelected.emit(this.uploadedFile);
      }
    }
  }

  removeFile(event: Event, index?: number): void {
    event.stopPropagation();
    
    if (this.multiple && index !== undefined) {
      this.uploadedFiles.splice(index, 1);
      this.onChange(this.uploadedFiles);
    } else {
      this.uploadedFile = null;
      this.uploadedFiles = [];
      this.onChange(null);
    }
    
    this.onTouched();
  }

  getFormData(fieldName: string = 'file'): FormData {
    const formData = new FormData();
    
    if (this.multiple) {
      this.uploadedFiles.forEach(file => {
        formData.append(fieldName, file);
      });
    } else if (this.uploadedFile) {
      formData.append(fieldName, this.uploadedFile);
    }
    
    return formData;
  }

  formatFileSize(bytes: number): string {
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  }
}
