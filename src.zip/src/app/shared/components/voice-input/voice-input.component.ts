import { Component, Output, EventEmitter, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-voice-input',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './voice-input.component.html',
  styleUrls: ['./voice-input.component.scss']
})
export class VoiceInputComponent implements OnDestroy {
  @Output() transcriptChange = new EventEmitter<string>();
  @Output() listeningChange = new EventEmitter<boolean>();
  
  @ViewChild('visualizer') visualizerCanvas?: ElementRef<HTMLCanvasElement>;
  
  isListening = false;
  transcript = '';
  interimTranscript = '';
  
  private recognition: any;
  private audioContext?: AudioContext;
  private analyser?: AnalyserNode;
  private dataArray?: Uint8Array;
  private animationId?: number;
  private stream?: MediaStream;
  private silenceTimeout?: any;
  private lastSpeechTime: number = 0;
  private readonly SILENCE_DURATION = 2000; // Auto-stop after 2 seconds of silence

  constructor() {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true; // Keep listening to detect silence
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
      this.recognition.maxAlternatives = 1;
      
      this.recognition.onstart = () => {
        console.log('[VoiceInput] Listening started');
        this.isListening = true;
        this.listeningChange.emit(true);
        this.lastSpeechTime = Date.now();
        this.startSilenceDetection();
      };
      
      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcriptText = event.results[i][0].transcript;
          
          if (event.results[i].isFinal) {
            final += transcriptText + ' ';
          } else {
            interim += transcriptText;
          }
        }
        
        if (final) {
          this.transcript += final;
          this.transcriptChange.emit(this.transcript);
        }
        
        this.interimTranscript = interim;
        
        // Reset silence timer when speech is detected
        this.lastSpeechTime = Date.now();
        this.startSilenceDetection();
      };
      
      this.recognition.onerror = (event: any) => {
        console.error('[VoiceInput] Error:', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          alert('Microphone access was denied. Please enable microphone permissions.');
        }
        this.stopListening();
      };
      
      this.recognition.onend = () => {
        if (this.isListening) {
          // Auto-restart if still supposed to be listening
          this.recognition.start();
        }
      };
    }
  }

  private startSilenceDetection(): void {
    if (this.silenceTimeout) {
      clearTimeout(this.silenceTimeout);
    }
    
    this.silenceTimeout = setTimeout(() => {
      const silenceDuration = Date.now() - this.lastSpeechTime;
      if (silenceDuration >= this.SILENCE_DURATION && this.isListening) {
        console.log('[VoiceInput] Auto-stopping due to silence');
        this.stopListening();
      }
    }, this.SILENCE_DURATION);
  }

  async startListening(): Promise<void> {
    if (!this.recognition) {
      alert('Speech recognition is not supported in your browser. Please use Chrome or Edge.');
      return;
    }
    
    try {
      // Start speech recognition
      this.transcript = '';
      this.interimTranscript = '';
      this.isListening = true;
      this.recognition.start();
      
      // Start audio visualization
      await this.startVisualization();
    } catch (error) {
      console.error('[VoiceInput] Error starting:', error);
      this.isListening = false;
      this.listeningChange.emit(false);
    }
  }

  stopListening(): void {
    this.isListening = false;
    this.listeningChange.emit(false);
    
    if (this.silenceTimeout) {
      clearTimeout(this.silenceTimeout);
      this.silenceTimeout = undefined;
    }
    
    if (this.recognition) {
      this.recognition.stop();
    }
    
    this.stopVisualization();
  }

  private async startVisualization(): Promise<void> {
    try {
      // Get microphone stream
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Create audio context and analyser
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = this.audioContext.createMediaStreamSource(this.stream);
      this.analyser = this.audioContext.createAnalyser();
      
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.8;
      const bufferLength = this.analyser.frequencyBinCount;
      this.dataArray = new Uint8Array(bufferLength);
      
      source.connect(this.analyser);
      
      // Start animation loop
      this.draw();
    } catch (error) {
      console.error('[VoiceInput] Microphone access error:', error);
    }
  }

  private stopVisualization(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = undefined;
    }
    
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = undefined;
    }
    
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = undefined;
    }
  }

  private draw(): void {
    if (!this.isListening || !this.analyser || !this.dataArray) {
      return;
    }
    
    this.animationId = requestAnimationFrame(() => this.draw());
    
    this.analyser.getByteTimeDomainData(this.dataArray);
    
    const canvas = this.visualizerCanvas?.nativeElement;
    if (!canvas) return;
    
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;
    
    const width = canvas.width;
    const height = canvas.height;
    
    // Clear canvas
    canvasCtx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    canvasCtx.fillRect(0, 0, width, height);
    
    // Draw waveform
    canvasCtx.lineWidth = 2;
    canvasCtx.strokeStyle = '#D04A02'; // PwC orange
    canvasCtx.beginPath();
    
    const sliceWidth = width / this.dataArray.length;
    let x = 0;
    
    for (let i = 0; i < this.dataArray.length; i++) {
      const v = this.dataArray[i] / 128.0;
      const y = (v * height) / 2;
      
      if (i === 0) {
        canvasCtx.moveTo(x, y);
      } else {
        canvasCtx.lineTo(x, y);
      }
      
      x += sliceWidth;
    }
    
    canvasCtx.lineTo(width, height / 2);
    canvasCtx.stroke();
  }

  ngOnDestroy(): void {
    this.stopListening();
    this.stopVisualization();
  }
}
