import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkflowCard } from '../../../core/models/guided-journey.models';

@Component({
  selector: 'app-guided-dialog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './guided-dialog.component.html',
  styleUrls: ['./guided-dialog.component.scss']
})
export class GuidedDialogComponent {
  @Input() isOpen: boolean = false;
  @Input() title: string = 'Guided Journey';
  @Input() workflows: WorkflowCard[] = [];
  @Input() showCloseButton: boolean = true;
  @Output() close = new EventEmitter<void>();
  @Output() workflowSelected = new EventEmitter<string>();

  onClose(): void {
    this.close.emit();
  }

  onBackdropClick(event: MouseEvent): void {
    if (event.target === event.currentTarget) {
      this.onClose();
    }
  }

  onWorkflowClick(workflowId: string): void {
    this.workflowSelected.emit(workflowId);
    this.onClose();
  }
}
